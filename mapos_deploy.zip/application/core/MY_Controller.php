<?php

class MY_Controller extends CI_Controller
{
    public $data = [
        'configuration' => [
            'per_page' => 10,
            'next_link' => 'Próxima',
            'prev_link' => 'Anterior',
            'full_tag_open' => '<div class="pagination alternate"><ul>',
            'full_tag_close' => '</ul></div>',
            'num_tag_open' => '<li>',
            'num_tag_close' => '</li>',
            'cur_tag_open' => '<li><a style="color: #2D335B"><b>',
            'cur_tag_close' => '</b></a></li>',
            'prev_tag_open' => '<li>',
            'prev_tag_close' => '</li>',
            'next_tag_open' => '<li>',
            'next_tag_close' => '</li>',
            'first_link' => 'Primeira',
            'last_link' => 'Última',
            'first_tag_open' => '<li>',
            'first_tag_close' => '</li>',
            'last_tag_open' => '<li>',
            'last_tag_close' => '</li>',
            'app_name' => 'Map-OS',
            'app_theme' => 'default',
            'os_notification' => 'cliente',
            'control_estoque' => '1',
            'notifica_whats' => '',
            'control_baixa' => '0',
            'control_editos' => '1',
            'control_datatable' => '1',
            'pix_key' => '',
        ],
    ];

    public function __construct()
    {
        parent::__construct();

        // Headers de seguranca para permitir geolocalizacao em iframes cross-origin
        // https://www.chromium.org/Home/chromium-security/deprecating-permissions-in-cross-origin-iframes/
        // Permissions-Policy é o header moderno (substitui Feature-Policy)
        header('Permissions-Policy: geolocation=(self)');

        // Carregar configurações primeiro (necessário para todas as áreas)
        $this->load_configuration();

        // Verificar se está acessando área do técnico (controller Tecnicos)
        // O controller Tecnicos tem sua própria autenticação
        $router = &load_class('Router', 'core');
        $controller = $router->fetch_class();
        $metodos_publicos_tecnico = ['login', 'autenticar', 'logout', 'api_login', 'api_verificar'];
        $metodo = $router->fetch_method();

        // Se for controller Tecnicos e método público, não redirecionar
        if (strtolower($controller) === 'tecnicos' && in_array($metodo, $metodos_publicos_tecnico)) {
            // Não redirecionar - o Tecnicos controller tem sua própria autenticação
        }
        // Se for controller Tecnicos mas método protegido, verificar sessão do técnico
        elseif (strtolower($controller) === 'tecnicos') {
            // Verifica sessão de técnico: nova (tec_logado) ou legada (logged_in + tec_id)
            $sessao_tecnico_valida = $this->session->userdata('tec_id') &&
                                     ($this->session->userdata('tec_logado') || $this->session->userdata('logged_in'));
            $sessao_admin_valida = $this->session->userdata('logado');
            if ((! session_id()) || (! $sessao_tecnico_valida && ! $sessao_admin_valida)) {
                redirect('tecnicos/login');
            }
        }
        // Para outros controllers, verificar sessão padrão (admin) OU sessão de técnico
        else {
            $sessao_admin = $this->session->userdata('logado');
            // Verifica sessão de técnico: nova (tec_logado) ou legada (logged_in + tec_id)
            $sessao_tecnico = $this->session->userdata('tec_id') &&
                              ($this->session->userdata('tec_logado') || $this->session->userdata('logged_in'));

            if ((! session_id()) || (! $sessao_admin && ! $sessao_tecnico)) {
                redirect('login');
            }
        }

        // Carregar library de permissoes
        $this->load->library('permission');
    }

    private function load_configuration()
    {
        $this->CI = &get_instance();
        $this->CI->load->database();
        $configuracoes = $this->CI->db->get('configuracoes')->result();

        foreach ($configuracoes as $c) {
            $this->data['configuration'][$c->config] = $c->valor;
        }
    }

    /**
     * Verifica se o usuario logado eh um tecnico
     * Baseado no grupo de permissao (NAO no idPermissao 1 = Administrador)
     */
    protected function isTecnico()
    {
        $permissao_id = $this->session->userdata('permissao');

        // Administrador (idPermissao 1) NUNCA é técnico
        if ($permissao_id == 1) {
            return false;
        }

        // Verifica se tem permissao especifica de tecnico
        $this->load->library('permission');
        return $this->permission->checkPermission($permissao_id, 'vTecnicoDashboard');
    }

    public function layout()
    {
        // Define se estamos na area do tecnico
        $this->data['is_area_tecnico'] = $this->isTecnico();

        // load views
        $this->load->view('tema/topo', $this->data);

        // Verifica se deve usar menu do portal do tecnico (flag definida no controller)
        if (!empty($this->data['use_menu_portal_tecnico'])) {
            $this->load->view('tema/menu_portal_tecnico', $this->data);
        }
        // Verifica se eh tecnico e carrega menu apropriado
        elseif ($this->isTecnico()) {
            $this->load->view('tema/menu_tecnico');
        } else {
            $this->load->view('tema/menu');
        }

        $this->load->view('tema/conteudo', $this->data);
        $this->load->view('tema/rodape');
    }
}
