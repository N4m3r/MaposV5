<?php
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * Controller de Gestão de Obras (Área Administrativa)
 */
class Obras extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('obras_model');
        $this->load->model('obra_atividades_model');

        // Carregar helper de atividades
        if (file_exists(APPPATH . 'helpers/atividades_helper.php')) {
            $this->load->helper('atividades');
        }

        // Carregar models opcionais apenas se existirem
        if (file_exists(APPPATH . 'models/obra_checkins_model.php')) {
            $this->load->model('obra_checkins_model');
        }
        if (file_exists(APPPATH . 'models/obra_cliente_model.php')) {
            $this->load->model('obra_cliente_model');
        }

        $this->data['menuObras'] = 'Obras';
    }

    // ============================================
    // CRUD BÁSICO
    // ============================================

    /**
     * Listar obras
     */
    public function index()
    {
        $this->gerenciar();
    }

    public function gerenciar()
    {
        $this->load->library('pagination');
        $this->load->model('mapos_model');

        // Filtros
        $filtros = [];
        $status = $this->input->get('status');
        $cliente = $this->input->get('cliente');

        if ($status) {
            $filtros['status'] = $status;
        }
        if ($cliente) {
            $filtros['cliente_id'] = $cliente;
        }

        // Configuração de paginação
        $config['base_url'] = site_url('obras/gerenciar');
        $config['total_rows'] = count($this->obras_model->getAll($filtros));
        $config['per_page'] = $this->data['configuration']['per_page'] ?? 10;
        $config['next_link'] = 'Próxima';
        $config['prev_link'] = 'Anterior';
        $config['full_tag_open'] = '<div class="pagination alternate"><ul>';
        $config['full_tag_close'] = '</ul></div>';

        $this->pagination->initialize($config);

        $this->data['results'] = $this->obras_model->getAll($filtros, $config['per_page'], $this->uri->segment(3));

        // Carregar configs para uso nas views (cores/status dinâmicos)
        $this->data['status_obra'] = $this->obras_model->getStatusObra() ?? [];

        // Debug: log dos dados carregados
        log_message('debug', 'Obras::gerenciar - Total de obras carregadas: ' . count($this->data['results']));

        $this->data['view'] = 'obras/obras_list';

        return $this->layout();
    }

    /**
     * Configurações do sistema de obras
     * Gerencia tipos, status, especialidades, funções e preferências
     */
    public function configuracoes()
    {
        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'cObras')) {
            $this->session->set_flashdata('error', 'Você não tem permissão para acessar as configurações de obras.');
            redirect('obras');
        }

        $this->load->model('atividades_tipos_model');
        $this->load->model('atividades_model');

        // Carregar configurações existentes ou valores padrão
        $this->data['config'] = $this->obras_model->getConfiguracoes() ?? [];
        $this->data['config_notif'] = $this->obras_model->getConfiguracoesNotificacoes() ?? [];

        // Carregar listas configuráveis
        $this->data['tipos_obra'] = $this->obras_model->getTiposObra() ?? [];
        $this->data['tipos_atividades'] = $this->atividades_tipos_model->listar() ?? [];
        $this->data['status_obra'] = $this->obras_model->getStatusObra() ?? [];
        $this->data['status_atividade'] = $this->atividades_model->getStatusAtividade() ?? [];
        $this->data['especialidades'] = $this->obras_model->getEspecialidades() ?? [];
        $this->data['funcoes_equipe'] = $this->obras_model->getFuncoesEquipe() ?? [];

        $this->data['view'] = 'obras/configuracoes';

        return $this->layout();
    }

    /**
     * Salvar configurações gerais do sistema de obras
     */
    public function salvarConfiguracao()
    {
        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'cObras')) {
            $this->session->set_flashdata('error', 'Sem permissão.');
            redirect('obras');
        }

        $config = [
            'nome_sistema' => $this->input->post('nome_sistema'),
            'prazo_inicio_padrao' => $this->input->post('prazo_inicio_padrao'),
            'prazo_execucao_padrao' => $this->input->post('prazo_execucao_padrao'),
            'habilitar_atividades' => $this->input->post('habilitar_atividades') ? true : false,
            'habilitar_etapas' => $this->input->post('habilitar_etapas') ? true : false,
            'habilitar_checkin' => $this->input->post('habilitar_checkin') ? true : false,
            'habilitar_gps' => $this->input->post('habilitar_gps') ? true : false,
            'habilitar_reatendimento' => $this->input->post('habilitar_reatendimento') ? true : false,
            'habilitar_portal_tecnico' => $this->input->post('habilitar_portal_tecnico') ? true : false,
        ];

        $result = $this->obras_model->salvarConfiguracoes($config);

        if ($result) {
            $this->session->set_flashdata('success', 'Configurações salvas com sucesso!');
        } else {
            $this->session->set_flashdata('error', 'Erro ao salvar configurações.');
        }

        redirect('obras/configuracoes');
    }

    /**
     * Salvar configurações de notificações
     */
    public function salvarConfiguracaoNotificacoes()
    {
        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'cObras')) {
            $this->session->set_flashdata('error', 'Sem permissão.');
            redirect('obras');
        }

        $config = [
            'nova_obra' => $this->input->post('notif_nova_obra') ? true : false,
            'obra_concluida' => $this->input->post('notif_obra_concluida') ? true : false,
            'atividade_atrasada' => $this->input->post('notif_atividade_atrasada') ? true : false,
            'atividade_reaberta' => $this->input->post('notif_atividade_reaberta') ? true : false,
            'checkin' => $this->input->post('notif_checkin') ? true : false,
            'impedimento' => $this->input->post('notif_impedimento') ? true : false,
            'canal_email' => $this->input->post('canal_email') ? true : false,
            'canal_sistema' => $this->input->post('canal_sistema') ? true : false,
        ];

        $result = $this->obras_model->salvarConfiguracoesNotificacoes($config);

        if ($result) {
            $this->session->set_flashdata('success', 'Configurações de notificações salvas com sucesso!');
        } else {
            $this->session->set_flashdata('error', 'Erro ao salvar configurações.');
        }

        redirect('obras/configuracoes');
    }

    /**
     * Adicionar obra
     */
    public function adicionar()
    {
        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'cObras')) {
            $this->session->set_flashdata('error', 'Você não tem permissão para adicionar obras.');
            redirect('obras');
        }

        $this->load->library('form_validation');
        $this->load->model('clientes_model');
        $this->load->model('usuarios_model');

        $this->data['clientes'] = $this->clientes_model->getAll();
        $this->data['tecnicos'] = $this->usuarios_model->getAll();

        if ($this->input->post()) {
            $this->form_validation->set_rules('nome', 'Nome', 'required|trim');
            $this->form_validation->set_rules('cliente_id', 'Cliente', 'required|numeric');

            if ($this->form_validation->run() == TRUE) {
                // Converter valor do contrato de formato brasileiro para formato do banco
                $valor_contrato = $this->input->post('valor_contrato');
                if (!empty($valor_contrato)) {
                    // Remove pontos de milhar e substitui vírgula por ponto
                    $valor_contrato = str_replace('.', '', $valor_contrato);
                    $valor_contrato = str_replace(',', '.', $valor_contrato);
                } else {
                    $valor_contrato = null;
                }

                $dados = [
                    'nome' => $this->input->post('nome'),
                    'cliente_id' => $this->input->post('cliente_id'),
                    'tipo_obra' => $this->input->post('tipo_obra') ?? 'Condominio',
                    'endereco' => $this->input->post('endereco'),
                    'bairro' => $this->input->post('bairro'),
                    'cidade' => $this->input->post('cidade'),
                    'estado' => $this->input->post('estado'),
                    'cep' => $this->input->post('cep'),
                    'data_inicio_contrato' => $this->input->post('data_inicio'),
                    'data_fim_prevista' => $this->input->post('data_previsao_fim'),
                    'observacoes' => $this->input->post('observacoes'),
                    'valor_contrato' => $valor_contrato,
                    'gestor_obra_id' => $this->input->post('gestor_obra_id'),
                    'responsavel_tecnico_id' => $this->input->post('responsavel_tecnico_id'),
                    'status' => 'Prospeccao',
                ];

                $obra_id = $this->obras_model->add($dados);

                if ($obra_id) {
                    log_info('Obra adicionada. ID: ' . $obra_id);

                    // Enfileirar email via sistema V5
                    try {
                        require_once APPPATH . 'libraries/Email/EmailQueue.php';
                        require_once APPPATH . 'libraries/Email/TemplateEngine.php';

                        $cliente = $this->clientes_model->getById($dados['cliente_id']);
                        if ($cliente && !empty($cliente->email)) {
                            $queue = new \Libraries\Email\EmailQueue();
                            $templates = new \Libraries\Email\TemplateEngine();

                            // Template configurado
                            $this->db->where('config', 'email_template_obra_nova');
                            $templateRow = $this->db->get('configuracoes')->row();
                            $template = $templateRow && !empty($templateRow->valor) ? $templateRow->valor : 'obra_nova';

                            // CC/BCC padrao
                            $cc = [];
                            $bcc = [];
                            $this->db->where('config', 'email_cc_default');
                            $rowCc = $this->db->get('configuracoes')->row();
                            if ($rowCc && !empty($rowCc->valor)) {
                                $cc = array_map('trim', explode(',', $rowCc->valor));
                            }
                            $this->db->where('config', 'email_bcc_default');
                            $rowBcc = $this->db->get('configuracoes')->row();
                            if ($rowBcc && !empty($rowBcc->valor)) {
                                $bcc = array_map('trim', explode(',', $rowBcc->valor));
                            }

                            $templateData = [
                                'cliente_nome' => $cliente->nomeCliente ?? '',
                                'cliente_email' => $cliente->email ?? '',
                                'os_titulo' => $dados['nome'] ?? 'Nova Obra',
                                'os_descricao' => $dados['observacoes'] ?? '',
                                'os_status' => $dados['status'] ?? 'Prospeccao',
                                'os_data_criacao' => date('d/m/Y'),
                                'os_link_visualizar' => base_url('obras/visualizar/' . $obra_id),
                            ];

                            $rendered = $templates->render($template, $templateData);

                            $enqueueData = [
                                'to' => $cliente->email,
                                'to_name' => $cliente->nomeCliente ?? '',
                                'subject' => 'Nova Obra Cadastrada - ' . $dados['nome'],
                                'body_html' => $rendered['html'],
                                'body_text' => $rendered['text'] ?? strip_tags($rendered['html']),
                                'template' => $template,
                                'template_data' => $templateData,
                                'priority' => 3,
                            ];
                            if (!empty($cc)) {
                                $enqueueData['cc'] = $cc;
                            }
                            if (!empty($bcc)) {
                                $enqueueData['bcc'] = $bcc;
                            }

                            $queue->enqueue($enqueueData);
                        }
                    } catch (\Exception $e) {
                        log_message('error', '[Obras] Erro ao enfileirar email V5: ' . $e->getMessage());
                    }

                    $this->session->set_flashdata('success', 'Obra adicionada com sucesso!');
                    redirect('obras/visualizar/' . $obra_id);
                } else {
                    $this->session->set_flashdata('error', 'Erro ao adicionar obra.');
                }
            }
        }

        // Carregar configs dinâmicas
        $this->data['tipos_obra'] = $this->obras_model->getTiposObra() ?? [];
        $this->data['status_obra'] = $this->obras_model->getStatusObra() ?? [];

        $this->data['view'] = 'obras/obra_form';
        return $this->layout();
    }

    /**
     * Editar obra
     */
    public function editar($id)
    {
        if (!$this->uri->segment(3) || !is_numeric($this->uri->segment(3))) {
            $this->session->set_flashdata('error', 'Obra não encontrada.');
            redirect('obras');
        }

        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'eObras')) {
            $this->session->set_flashdata('error', 'Você não tem permissão para editar obras.');
            redirect('obras');
        }

        $this->load->library('form_validation');
        $this->load->model('clientes_model');
        $this->load->model('usuarios_model');

        $obra_id = $this->uri->segment(3);
        $this->data['result'] = $this->obras_model->getByIdCompleto($obra_id);

        if (!$this->data['result']) {
            $this->session->set_flashdata('error', 'Obra não encontrada.');
            redirect('obras');
        }

        $this->data['clientes'] = $this->clientes_model->getAll();
        $this->data['tecnicos'] = $this->usuarios_model->getAll();

        if ($this->input->post()) {
            $this->form_validation->set_rules('nome', 'Nome', 'required|trim');

            if ($this->form_validation->run() == TRUE) {
                // Converter valor do contrato de formato brasileiro para formato do banco
                $valor_contrato = $this->input->post('valor_contrato');
                if (!empty($valor_contrato)) {
                    // Remove pontos de milhar e substitui vírgula por ponto
                    $valor_contrato = str_replace('.', '', $valor_contrato);
                    $valor_contrato = str_replace(',', '.', $valor_contrato);
                } else {
                    $valor_contrato = null;
                }

                $dados = [
                    'nome' => $this->input->post('nome'),
                    'tipo_obra' => $this->input->post('tipo_obra'),
                    'endereco' => $this->input->post('endereco'),
                    'bairro' => $this->input->post('bairro'),
                    'cidade' => $this->input->post('cidade'),
                    'estado' => $this->input->post('estado'),
                    'cep' => $this->input->post('cep'),
                    'data_inicio_contrato' => $this->input->post('data_inicio'),
                    'data_fim_prevista' => $this->input->post('data_previsao_fim'),
                    'observacoes' => $this->input->post('observacoes'),
                    'status' => $this->input->post('status'),
                    'valor_contrato' => $valor_contrato,
                    'gestor_obra_id' => $this->input->post('gestor_obra_id'),
                    'responsavel_tecnico_id' => $this->input->post('responsavel_tecnico_id'),
                ];

                // Apenas incluir visivel_cliente se o campo existir no POST
                if ($this->input->post('visivel_cliente') !== null) {
                    $dados['visivel_cliente'] = $this->input->post('visivel_cliente') ? 1 : 0;
                }

                // Log para debug
                log_message('debug', 'Editar obra ID ' . $obra_id . ' - Dados: ' . print_r($dados, true));

                if ($this->obras_model->update($obra_id, $dados)) {
                    log_info('Obra atualizada. ID: ' . $obra_id);
                    $this->session->set_flashdata('success', 'Obra atualizada com sucesso!');
                    redirect('obras/visualizar/' . $obra_id);
                } else {
                    $this->session->set_flashdata('error', 'Erro ao atualizar obra.');
                }
            }
        }

        // Carregar configs dinâmicas
        $this->data['tipos_obra'] = $this->obras_model->getTiposObra() ?? [];
        $this->data['status_obra'] = $this->obras_model->getStatusObra() ?? [];

        $this->data['view'] = 'obras/obra_form';
        return $this->layout();
    }

    /**
     * Visualizar obra (Dashboard)
     */
    public function visualizar($id = null)
    {
        if (!$id || !is_numeric($id)) {
            $this->session->set_flashdata('error', 'Obra não encontrada.');
            redirect('obras');
        }

        $this->load->model('mapos_model');
        $this->load->model('usuarios_model');

        $this->data['obra'] = $this->obras_model->getById($id);

        if (!$this->data['obra']) {
            $this->session->set_flashdata('error', 'Obra não encontrada.');
            redirect('obras');
        }

        $this->data['etapas'] = $this->obras_model->getEtapasComEstatisticas($id);
        $this->data['equipe'] = $this->obras_model->getEquipe($id);

        // Carregar configs dinâmicas
        $this->data['tipos_obra'] = $this->obras_model->getTiposObra() ?? [];
        $this->data['status_obra'] = $this->obras_model->getStatusObra() ?? [];

        // Buscar atividades recentes organizadas por etapa
        $atividades = $this->obra_atividades_model->getByObra($id, [], 50);
        $this->data['atividades_recentes'] = $atividades;

        // Organizar atividades por etapa para fácil acesso na view
        $this->data['atividades_por_etapa'] = [];
        foreach ($atividades as $atividade) {
            $etapa_id = $atividade->etapa_id ?? 0;
            if (!isset($this->data['atividades_por_etapa'][$etapa_id])) {
                $this->data['atividades_por_etapa'][$etapa_id] = [];
            }
            $this->data['atividades_por_etapa'][$etapa_id][] = $atividade;
        }

        // Atividades do novo sistema (Hora Início/Fim)
        if (file_exists(APPPATH . 'models/Atividades_model.php')) {
            $this->load->model('Atividades_model', 'atividades_novas');
            $this->data['atividades_sistema'] = $this->atividades_novas->listarPorObra($id, [], 20);

            // Estatísticas das atividades do novo sistema
            $this->data['estatisticas_atividades'] = $this->atividades_novas->getEstatisticasPorObra($id);

            // Tipos de atividades para iniciar trabalho
            $this->load->model('Atividades_tipos_model');
            $this->data['tipos_atividades'] = $this->Atividades_tipos_model->listarPorCategoria();
        } else {
            $this->data['atividades_sistema'] = [];
            $this->data['estatisticas_atividades'] = null;
            $this->data['tipos_atividades'] = [];
        }

        $this->data['view'] = 'obras/obra_view';
        return $this->layout();
    }

    /**
     * Excluir obra
     */
    public function excluir()
    {
        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'dObras')) {
            $this->session->set_flashdata('error', 'Você não tem permissão para excluir obras.');
            redirect('obras');
        }

        $id = $this->input->post('id');

        if ($id && is_numeric($id)) {
            if ($this->obras_model->delete($id)) {
                log_info('Obra excluída. ID: ' . $id);
                $this->session->set_flashdata('success', 'Obra excluída com sucesso!');
            } else {
                $this->session->set_flashdata('error', 'Erro ao excluir obra.');
            }
        }

        redirect('obras');
    }

    // ============================================
    // ETAPAS
    // ============================================

    /**
     * Listar etapas da obra
     */
    public function etapas($obra_id)
    {
        if (!$obra_id || !is_numeric($obra_id)) {
            $this->session->set_flashdata('error', 'Obra não encontrada.');
            redirect('obras');
        }

        $this->load->model('mapos_model');

        $this->data['obra'] = $this->obras_model->getById($obra_id);

        if (!$this->data['obra']) {
            $this->session->set_flashdata('error', 'Obra não encontrada.');
            redirect('obras');
        }

        $this->data['etapas'] = $this->obras_model->getEtapasComEstatisticas($obra_id);
        $this->data['equipe'] = $this->obras_model->getEquipe($obra_id);
        $this->data['atividades_recentes'] = $this->obra_atividades_model->getByObra($obra_id, [], 20);

        // Carregar configs dinâmicas
        $this->data['especialidades'] = $this->obras_model->getEspecialidades() ?? [];
        $this->data['status_obra'] = $this->obras_model->getStatusObra() ?? [];

        // Atividades do novo sistema (Hora Início/Fim)
        if (file_exists(APPPATH . 'models/Atividades_model.php')) {
            $this->load->model('Atividades_model', 'atividades_novas');
            $this->data['estatisticas_atividades'] = $this->atividades_novas->getEstatisticasPorObra($obra_id);
        } else {
            $this->data['estatisticas_atividades'] = null;
        }

        // Organizar atividades por etapa
        $this->data['atividades_por_etapa'] = [];
        foreach ($this->data['atividades_recentes'] as $atividade) {
            $etapa_id = $atividade->etapa_id ?? 0;
            if (!isset($this->data['atividades_por_etapa'][$etapa_id])) {
                $this->data['atividades_por_etapa'][$etapa_id] = [];
            }
            $this->data['atividades_por_etapa'][$etapa_id][] = $atividade;
        }

        $this->data['view'] = 'obras/etapas_list';

        return $this->layout();
    }

    /**
     * Adicionar etapa
     */
    public function adicionarEtapa()
    {
        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'eObras')) {
            $this->session->set_flashdata('error', 'Sem permissão para adicionar etapas.');
            redirect('obras');
        }

        $obra_id = $this->input->post('obra_id');
        $nome = $this->input->post('nome');

        if (!$obra_id) {
            $this->session->set_flashdata('error', 'ID da obra não informado.');
            redirect('obras');
        }

        if (!$nome) {
            $this->session->set_flashdata('error', 'Nome da etapa é obrigatório.');
            redirect('obras/etapas/' . $obra_id);
        }

        $dados = [
            'obra_id' => $obra_id,
            'numero_etapa' => $this->input->post('numero_etapa') ?: 1,
            'nome' => $nome,
            'descricao' => $this->input->post('descricao'),
            'especialidade' => $this->input->post('especialidade'),
            'data_inicio_prevista' => $this->input->post('data_inicio_prevista'),
            'data_fim_prevista' => $this->input->post('data_fim_prevista'),
        ];

        $etapa_id = $this->obras_model->adicionarEtapa($obra_id, $dados);

        if ($etapa_id) {
            $this->session->set_flashdata('success', 'Etapa "' . $nome . '" adicionada com sucesso!');
        } else {
            $this->session->set_flashdata('error', 'Erro ao adicionar etapa. Verifique os dados e tente novamente.');
        }

        redirect('obras/etapas/' . $obra_id);
    }

    /**
     * Editar etapa
     */
    public function editarEtapa($etapa_id)
    {
        if (!$etapa_id || !is_numeric($etapa_id)) {
            $this->session->set_flashdata('error', 'ID da etapa inválido.');
            redirect('obras');
            return;
        }

        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'eObras')) {
            $this->session->set_flashdata('error', 'Sem permissão para editar etapas.');
            redirect('obras');
            return;
        }

        // Buscar etapa
        $etapa = $this->obras_model->getEtapaById($etapa_id);
        if (!$etapa) {
            $this->session->set_flashdata('error', 'Etapa não encontrada.');
            redirect('obras');
            return;
        }

        $obra_id = $etapa->obra_id;

        // Processar formulário
        if ($this->input->post()) {
            $dados = [
                'numero_etapa' => $this->input->post('numero_etapa') ?: 1,
                'nome' => $this->input->post('nome'),
                'descricao' => $this->input->post('descricao'),
                'especialidade' => $this->input->post('especialidade'),
                'data_inicio_prevista' => $this->input->post('data_inicio_prevista'),
                'data_fim_prevista' => $this->input->post('data_fim_prevista'),
                'status' => $this->input->post('status') ?: 'NaoIniciada',
            ];

            if (!$dados['nome']) {
                $this->session->set_flashdata('error', 'Nome da etapa é obrigatório.');
                redirect('obras/editarEtapa/' . $etapa_id);
                return;
            }

            $result = $this->obras_model->atualizarEtapa($etapa_id, $dados);

            if ($result) {
                $this->session->set_flashdata('success', 'Etapa atualizada com sucesso!');
                redirect('obras/etapas/' . $obra_id);
            } else {
                $this->session->set_flashdata('error', 'Erro ao atualizar etapa.');
                redirect('obras/editarEtapa/' . $etapa_id);
            }
            return;
        }

        $this->data['obra'] = $this->obras_model->getById($obra_id);
        $this->data['etapa'] = $etapa;
        $this->data['etapas'] = $this->obras_model->getEtapas($obra_id);

        // Carregar configs dinâmicas
        $this->data['especialidades'] = $this->obras_model->getEspecialidades() ?? [];
        $this->data['status_obra'] = $this->obras_model->getStatusObra() ?? [];

        $this->data['view'] = 'obras/etapa_edit';

        return $this->layout();
    }

    /**
     * Excluir etapa
     */
    public function excluirEtapa($etapa_id)
    {
        if (!$etapa_id || !is_numeric($etapa_id)) {
            $this->session->set_flashdata('error', 'ID da etapa inválido.');
            redirect('obras');
            return;
        }

        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'dObras')) {
            $this->session->set_flashdata('error', 'Sem permissão para excluir etapas.');
            redirect('obras');
            return;
        }

        // Buscar etapa para obter obra_id antes de excluir
        $etapa = $this->obras_model->getEtapaById($etapa_id);
        if (!$etapa) {
            $this->session->set_flashdata('error', 'Etapa não encontrada.');
            redirect('obras');
            return;
        }

        $obra_id = $etapa->obra_id;

        $result = $this->obras_model->excluirEtapa($etapa_id);

        if ($result) {
            $this->session->set_flashdata('success', 'Etapa excluída com sucesso!');
        } else {
            $this->session->set_flashdata('error', 'Erro ao excluir etapa.');
        }

        redirect('obras/etapas/' . $obra_id);
    }

    // ============================================
    // EQUIPE
    // ============================================

    /**
     * Gerenciar equipe da obra
     */
    public function equipe($obra_id)
    {
        if (!$obra_id || !is_numeric($obra_id)) {
            $this->session->set_flashdata('error', 'Obra não encontrada.');
            redirect('obras');
        }

        $this->load->model('usuarios_model');

        $this->data['obra'] = $this->obras_model->getById($obra_id);
        $this->data['equipe'] = $this->obras_model->getEquipe($obra_id);
        $this->data['tecnicos'] = $this->usuarios_model->getAll();

        // Carregar configs dinâmicas
        $this->data['funcoes_equipe'] = $this->obras_model->getFuncoesEquipe() ?? [];

        $this->data['view'] = 'obras/equipe';

        return $this->layout();
    }

    /**
     * Adicionar técnico à equipe
     */
    public function adicionarTecnico()
    {
        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'eObras')) {
            $this->session->set_flashdata('error', 'Sem permissão.');
            redirect('obras');
        }

        $obra_id = $this->input->post('obra_id');
        $tecnico_id = $this->input->post('tecnico_id');
        $funcao = $this->input->post('funcao') ?: 'Técnico';

        if (!$obra_id || !$tecnico_id) {
            $this->session->set_flashdata('error', 'Dados incompletos.');
            redirect('obras/equipe/' . $obra_id);
        }

        // Verificar se técnico já está na equipe
        if ($this->obras_model->tecnicoNaEquipe($obra_id, $tecnico_id)) {
            $this->session->set_flashdata('error', 'Técnico já está na equipe desta obra.');
            redirect('obras/equipe/' . $obra_id);
        }

        if ($this->obras_model->adicionarTecnicoEquipe($obra_id, $tecnico_id, $funcao)) {
            $this->session->set_flashdata('success', 'Técnico adicionado à equipe com sucesso!');

            // Buscar informações da obra para a notificação
            $obra = $this->obras_model->getById($obra_id);
            $obra_nome = $obra ? ($obra->obra_nome ?? $obra->nome ?? 'Obra #' . $obra_id) : 'Obra #' . $obra_id;

            // Enviar notificação ao técnico
            $this->load->model('notificacoes_model');
            $this->notificacoes_model->ensureTableExists();

            $this->notificacoes_model->adicionar([
                'usuario_id' => $tecnico_id,
                'tipo_usuario' => 'tecnico',
                'titulo' => 'Adicionado à Equipe',
                'mensagem' => 'Você foi adicionado à equipe da obra: ' . $obra_nome . ' como ' . $funcao,
                'url' => site_url('tecnicos/minhas_obras'),
                'tipo' => 'success',
                'icone' => 'bx-building'
            ]);
        } else {
            $this->session->set_flashdata('error', 'Erro ao adicionar técnico à equipe.');
        }

        redirect('obras/equipe/' . $obra_id);
    }

    /**
     * Remover técnico da equipe
     */
    public function removerTecnico($equipe_id)
    {
        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'eObras')) {
            $this->session->set_flashdata('error', 'Sem permissão.');
            redirect('obras');
        }

        if (!$equipe_id || !is_numeric($equipe_id)) {
            $this->session->set_flashdata('error', 'Registro não encontrado.');
            redirect('obras');
        }

        // Buscar informação da equipe para redirecionar após remover
        $this->db->where('id', $equipe_id);
        $query = $this->db->get('obra_equipe');
        $equipe = $query ? $query->row() : null;

        if ($this->obras_model->removerTecnicoEquipe($equipe_id)) {
            $this->session->set_flashdata('success', 'Técnico removido da equipe com sucesso!');
        } else {
            $this->session->set_flashdata('error', 'Erro ao remover técnico da equipe.');
        }

        redirect('obras/equipe/' . ($equipe ? $equipe->obra_id : 'gerenciar'));
    }

    // ============================================
    // ATIVIDADES
    // ============================================

    /**
     * Listar atividades da obra
     */
    public function atividades($obra_id)
    {
        if (!$obra_id || !is_numeric($obra_id)) {
            $this->session->set_flashdata('error', 'Obra não encontrada.');
            redirect('obras');
        }

        $this->load->model('usuarios_model');

        $this->data['obra'] = $this->obras_model->getById($obra_id);

        if (!$this->data['obra']) {
            $this->session->set_flashdata('error', 'Obra não encontrada.');
            redirect('obras');
        }

        // Atividades agendadas do sistema antigo (com joins para técnico e etapa)
        $this->data['atividades'] = $this->obra_atividades_model->getByObra($obra_id);

        // Carrega dados do sistema de registro de atividades (Hora Início/Fim) se disponível
        if (file_exists(APPPATH . 'models/Atividades_model.php')) {
            $this->load->model('Atividades_model', 'atividades_sistema');
            $this->load->model('Atividades_tipos_model');

            // Atividades registradas com Hora Início/Fim
            $this->data['atividades_registradas'] = $this->atividades_sistema->listarPorObra($obra_id, [], 50);

            // Estatísticas das atividades registradas
            $this->data['estatisticas_registro'] = $this->atividades_sistema->getEstatisticasPorObra($obra_id);

            // Tipos de atividades para o formulário de registro (lista plana)
            $this->data['tipos_atividades'] = $this->Atividades_tipos_model->listar([], true);
        } else {
            $this->data['atividades_registradas'] = [];
            $this->data['estatisticas_registro'] = null;
            $this->data['tipos_atividades'] = [];
        }

        $this->data['tecnicos'] = $this->usuarios_model->getAll();
        $this->data['etapas'] = $this->obras_model->getEtapas($obra_id);

        // Carregar configs dinâmicas
        $this->load->model('atividades_model');
        $this->data['status_atividade'] = $this->atividades_model->getStatusAtividade() ?? [];

        $this->data['view'] = 'obras/atividades_novo';

        return $this->layout();
    }

    /**
     * Adicionar atividade
     */
    public function adicionarAtividade()
    {
        $obra_id = $this->input->post('obra_id');

        // Debug: verificar se tabela existe
        if (!$this->db->table_exists('obra_atividades')) {
            log_message('error', 'Tabela obra_atividades nao existe');
            $this->session->set_flashdata('error', 'Erro: Tabela de atividades nao existe. Execute as migracoes.');
            redirect('obras/atividades/' . $obra_id);
            return;
        }

        // Debug: verificar POST recebido
        log_message('debug', 'adicionarAtividade - POST etapa_id: ' . var_export($this->input->post('etapa_id'), true));

        $dados = [
            'obra_id' => $obra_id,
            'etapa_id' => $this->input->post('etapa_id') ? (int)$this->input->post('etapa_id') : null,
            'tecnico_id' => $this->input->post('tecnico_id') ? (int)$this->input->post('tecnico_id') : null,
            'data_atividade' => $this->input->post('data_atividade'),
            'titulo' => $this->input->post('titulo'),
            'descricao' => $this->input->post('descricao'),
            'tipo' => $this->input->post('tipo') ?: 'trabalho',
            'visivel_cliente' => $this->input->post('visivel_cliente') ? 1 : 0,
        ];

        log_message('debug', 'adicionarAtividade - Dados preparados: ' . print_r($dados, true));

        // Validar dados obrigatorios
        if (empty($dados['titulo'])) {
            $this->session->set_flashdata('error', 'Erro: Titulo da atividade e obrigatorio.');
            redirect('obras/atividades/' . $obra_id);
            return;
        }

        if (empty($dados['data_atividade'])) {
            $this->session->set_flashdata('error', 'Erro: Data da atividade e obrigatoria.');
            redirect('obras/atividades/' . $obra_id);
            return;
        }

        $atividade_id = $this->obra_atividades_model->add($dados);

        if ($atividade_id) {
            // Recalcular progresso da obra após adicionar atividade
            $this->obras_model->atualizarProgressoPorAtividades($obra_id);

            $this->session->set_flashdata('success', 'Atividade adicionada com sucesso!');
        } else {
            $error = $this->db->error();
            log_message('error', 'Erro ao adicionar atividade: ' . print_r($error, true));
            $this->session->set_flashdata('error', 'Erro ao adicionar atividade: ' . ($error['message'] ?? 'Erro desconhecido'));
        }

        redirect('obras/atividades/' . $obra_id);
    }

    /**
     * Excluir atividade
     */
    public function excluirAtividade($atividade_id)
    {
        log_message('debug', 'excluirAtividade chamado com ID: ' . var_export($atividade_id, true));

        if (!$atividade_id || !is_numeric($atividade_id)) {
            log_message('error', 'excluirAtividade - ID inválido: ' . var_export($atividade_id, true));
            $this->session->set_flashdata('error', 'ID da atividade inválido.');
            redirect('obras');
            return;
        }

        // DEBUG: Verificar permissão
        $permissao = $this->session->userdata('permissao');
        log_message('debug', 'excluirAtividade - Permissão do usuário: ' . var_export($permissao, true));

        // Buscar atividade para obter obra_id (para redirecionamento)
        $atividade = $this->obra_atividades_model->getById($atividade_id);
        log_message('debug', 'excluirAtividade - Atividade encontrada: ' . ($atividade ? 'SIM' : 'NÃO'));

        if (!$atividade) {
            $this->session->set_flashdata('error', 'Atividade não encontrada.');
            redirect('obras');
            return;
        }

        $obra_id = $atividade->obra_id;
        log_message('debug', 'excluirAtividade - Obra ID: ' . $obra_id);

        // Excluir atividade
        $result = $this->obra_atividades_model->delete($atividade_id);
        log_message('debug', 'excluirAtividade - Resultado do delete: ' . ($result ? 'SUCESSO' : 'FALHA'));

        if ($result) {
            // Recalcular progresso da obra após exclusão
            $this->obras_model->atualizarProgressoPorAtividades($obra_id);
            log_message('info', 'Progresso da obra ' . $obra_id . ' recalculado após exclusão da atividade ' . $atividade_id);

            $this->session->set_flashdata('success', 'Atividade excluída com sucesso!');
        } else {
            $error = $this->db->error();
            log_message('error', 'excluirAtividade - Erro DB: ' . print_r($error, true));
            $this->session->set_flashdata('error', 'Erro ao excluir atividade.');
        }

        redirect('obras/atividades/' . $obra_id);
    }

    /**
     * Verificar atividades no banco (debug)
     */
    public function verificarAtividades($obra_id)
    {
        if (!$obra_id || !is_numeric($obra_id)) {
            echo 'Obra ID inválido';
            return;
        }

        echo '<h2>Verificação de Atividades - Obra ID: ' . $obra_id . '</h2>';
        echo '<hr>';

        // Verificar se tabela existe
        $tabela_existe = $this->db->table_exists('obra_atividades');
        echo '<p><strong>Tabela obra_atividades existe:</strong> ' . ($tabela_existe ? 'SIM' : 'NÃO') . '</p>';

        if (!$tabela_existe) {
            echo '<p style="color: red;">A tabela não existe! Crie as tabelas primeiro.</p>';
            echo '<a href="' . site_url('diagnostico/obras') . '">Ir para Diagnóstico</a>';
            return;
        }

        // Mostrar estrutura da tabela
        echo '<h3>Estrutura da tabela:</h3>';
        echo '<pre>';
        $fields = $this->db->list_fields('obra_atividades');
        print_r($fields);
        echo '</pre>';

        // DEBUG: Verificar colunas específicas
        echo '<div style="background: #fff3cd; border: 2px solid #ffc107; padding: 15px; margin: 15px 0;">';
        echo '<strong>DEBUG:</strong> Verificando colunas...';
        echo '<ul>';
        echo '<li>tecnico_id existe: ' . (in_array('tecnico_id', $fields) ? 'SIM' : 'NÃO') . '</li>';
        echo '<li>usuario_id existe: ' . (in_array('usuario_id', $fields) ? 'SIM' : 'NÃO') . '</li>';
        echo '<li>etapa_id existe: ' . (in_array('etapa_id', $fields) ? 'SIM' : 'NÃO') . '</li>';
        echo '<li>titulo existe: ' . (in_array('titulo', $fields) ? 'SIM' : 'NÃO') . '</li>';
        echo '<li>status existe: ' . (in_array('status', $fields) ? 'SIM' : 'NÃO') . '</li>';
        echo '<li>data_atividade existe: ' . (in_array('data_atividade', $fields) ? 'SIM' : 'NÃO') . '</li>';
        echo '</ul>';
        echo '</div>';

        // Query direta primeiro (igual ao método antigo)
        echo '<h3>Query Direta (sem model):</h3>';
        $query_direta = $this->db->where('obra_id', $obra_id)->get('obra_atividades');
        $result_direto = $query_direta ? $query_direta->result() : [];
        echo '<p>Total via query direta: ' . count($result_direto) . '</p>';
        echo '<pre style="background: #e3f2fd; padding: 10px;">';
        print_r($result_direto);
        echo '</pre>';

        // Agora usar o model
        echo '<hr>';
        echo '<h3>Via Model (com joins):</h3>';

        // Capturar possíveis erros
        try {
            $atividades = $this->obra_atividades_model->getByObra($obra_id);
            $total = count($atividades);
            echo '<p><strong>Total via model:</strong> ' . $total . '</p>';

            if ($total > 0) {
                echo '<h4>Primeira atividade (detalhada):</h4>';
                echo '<pre style="background: #d4edda; padding: 10px;">';
                print_r($atividades[0]);
                echo '</pre>';

                echo '<h4>Campos disponíveis:</h4>';
                echo '<ul>';
                foreach ($atividades[0] as $key => $value) {
                    echo '<li>' . $key . ' = ' . (is_string($value) || is_numeric($value) ? $value : json_encode($value)) . '</li>';
                }
                echo '</ul>';
            }
        } catch (Exception $e) {
            echo '<p style="color: red;"><strong>ERRO:</strong> ' . $e->getMessage() . '</p>';
            $atividades = [];
            $total = 0;
        }

        echo '<p><strong>Total de atividades nesta obra:</strong> ' . $total . '</p>';
        echo '<p><strong>Query executada:</strong> ' . $this->db->last_query() . '</p>';

        if ($total > 0) {
            echo '<h3>Atividades encontradas:</h3>';
            echo '<table border="1" cellpadding="10" style="border-collapse: collapse;">';
            echo '<tr style="background: #f0f0f0;">';
            echo '<th>ID</th>';
            echo '<th>Título</th>';
            echo '<th>Descrição</th>';
            echo '<th>Data</th>';
            echo '<th>Status</th>';
            echo '<th>Tipo</th>';
            echo '<th>Técnico</th>';
            echo '<th>Etapa</th>';
            echo '<th>Progresso</th>';
            echo '<th>Visível</th>';
            echo '</tr>';
            foreach ($atividades as $ativ) {
                $tecnico = $ativ->tecnico_nome ?? ($ativ->usuario_nome ?? 'N/A');
                $etapa = ($ativ->etapa_nome ?? '') . (($ativ->numero_etapa ?? '') ? ' #' . $ativ->numero_etapa : '');
                $etapa = trim($etapa) ?: 'N/A';
                $titulo = $ativ->titulo ?? $ativ->descricao ?? 'Sem título';
                $data = $ativ->data_atividade ?? ($ativ->created_at ? date('Y-m-d', strtotime($ativ->created_at)) : 'N/A');

                echo '<tr>';
                echo '<td>' . ($ativ->id ?? 'N/A') . '</td>';
                echo '<td>' . htmlspecialchars($titulo) . '</td>';
                echo '<td>' . htmlspecialchars($ativ->descricao ?? '') . '</td>';
                echo '<td>' . $data . '</td>';
                echo '<td>' . ($ativ->status ?? 'agendada') . '</td>';
                echo '<td>' . ($ativ->tipo ?? 'trabalho') . '</td>';
                echo '<td>' . htmlspecialchars($tecnico) . '</td>';
                echo '<td>' . htmlspecialchars($etapa) . '</td>';
                echo '<td>' . ($ativ->percentual_concluido ?? 0) . '%</td>';
                echo '<td>' . (($ativ->visivel_cliente ?? 1) ? 'Sim' : 'Não') . '</td>';
                echo '</tr>';
            }
            echo '</table>';

            // Também mostrar dados brutos
            echo '<h3>Dados completos (raw):</h3>';
            echo '<pre style="background: #f5f5f5; padding: 15px; overflow-x: auto;">';
            print_r($atividades);
            echo '</pre>';
        } else {
            echo '<p style="color: orange;">Nenhuma atividade encontrada para esta obra.</p>';
        }

        echo '<hr>';

        // Verificar se há atividades em outras obras
        echo '<h3>Verificação em Outras Obras</h3>';
        $this->db->select('obra_id, COUNT(*) as total');
        $this->db->group_by('obra_id');
        $query = $this->db->get('obra_atividades');
        $atividades_por_obra = $query->result();

        if (!empty($atividades_por_obra)) {
            echo '<table border="1" cellpadding="10" style="border-collapse: collapse;">';
            echo '<tr><th>Obra ID</th><th>Total Atividades</th><th>Ação</th></tr>';
            foreach ($atividades_por_obra as $row) {
                echo '<tr>';
                echo '<td>' . $row->obra_id . '</td>';
                echo '<td>' . $row->total . '</td>';
                echo '<td><a href="' . site_url('obras/verificarAtividades/' . $row->obra_id) . '">Verificar</a></td>';
                echo '</tr>';
            }
            echo '</table>';
        } else {
            echo '<p style="color: orange;">Nenhuma atividade encontrada em NENHUMA obra.</p>';
        }

        echo '<hr>';
        echo '<div style="display: flex; gap: 10px; flex-wrap: wrap;">';
        echo '<a href="' . site_url('obras/atividades/' . $obra_id) . '" class="btn">Voltar para Atividades</a>';
        echo '<a href="' . site_url('obras/criarAtividadeTeste/' . $obra_id) . '" class="btn" style="background: #17a2b8; color: white; padding: 5px 10px; text-decoration: none;">Criar Atividade de Teste</a>';
        echo '<a href="' . site_url('diagnostico') . '" class="btn" style="background: #ffc107; color: #000; padding: 5px 10px; text-decoration: none;">Diagnóstico</a>';
        echo '</div>';
    }

    /**
     * Criar atividade de teste
     */
    public function criarAtividadeTeste($obra_id)
    {
        if (!$obra_id || !is_numeric($obra_id)) {
            echo 'Obra ID inválido';
            return;
        }

        // Verificar se tabela existe
        if (!$this->db->table_exists('obra_atividades')) {
            echo '<p style="color: red;">Tabela não existe!</p>';
            return;
        }

        $dados = [
            'obra_id' => $obra_id,
            'titulo' => 'Atividade de Teste ' . date('H:i:s'),
            'descricao' => 'Esta é uma atividade de teste criada automaticamente',
            'tipo' => 'trabalho',
            'status' => 'agendada',
            'data_atividade' => date('Y-m-d'),
            'percentual_concluido' => 0,
            'visivel_cliente' => 1,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Verificar campos existentes
        $colunas = $this->db->list_fields('obra_atividades');
        $dados_filtrados = [];
        foreach ($dados as $campo => $valor) {
            if (in_array($campo, $colunas)) {
                $dados_filtrados[$campo] = $valor;
            }
        }

        $this->db->insert('obra_atividades', $dados_filtrados);
        $id = $this->db->insert_id();

        if ($id) {
            echo '<p style="color: green;">✅ Atividade de teste criada com sucesso! ID: ' . $id . '</p>';
            echo '<a href="' . site_url('obras/verificarAtividades/' . $obra_id) . '">Verificar Atividades</a>';
        } else {
            echo '<p style="color: red;">❌ Erro ao criar atividade</p>';
        }
    }

    /**
     * Wizard - Salvar etapa e atividades
     */
    public function salvarWizard($obra_id)
    {
        if (!$obra_id || !is_numeric($obra_id)) {
            $this->session->set_flashdata('error', 'Obra invalida.');
            redirect('obras');
        }

        // Verificar se tabelas existem
        if (!$this->db->table_exists('obra_etapas')) {
            $this->session->set_flashdata('error', 'Tabela obra_etapas nao existe. Execute o diagnostico primeiro.');
            redirect('obras/visualizar/' . $obra_id);
        }

        // Log dos dados recebidos
        log_message('debug', 'salvarWizard - POST data: ' . print_r($this->input->post(), true));

        $this->db->trans_start();

        try {
            // Verificar campos da tabela obra_etapas
            $campos_etapas = $this->db->list_fields('obra_etapas');
            log_message('debug', 'salvarWizard - Campos obra_etapas: ' . implode(', ', $campos_etapas));

            // 1. Salvar a etapa - apenas com campos que existem
            $etapa_data = ['obra_id' => $obra_id];

            if (in_array('numero_etapa', $campos_etapas)) {
                $etapa_data['numero_etapa'] = $this->input->post('etapa_numero') ?: 1;
            }
            if (in_array('nome', $campos_etapas)) {
                $etapa_data['nome'] = $this->input->post('etapa_nome') ?: 'Nova Etapa';
            }
            if (in_array('descricao', $campos_etapas)) {
                $etapa_data['descricao'] = $this->input->post('etapa_descricao') ?: '';
            }
            if (in_array('data_inicio_prevista', $campos_etapas)) {
                $etapa_data['data_inicio_prevista'] = $this->input->post('etapa_data_inicio') ?: null;
            }
            if (in_array('data_fim_prevista', $campos_etapas)) {
                $etapa_data['data_fim_prevista'] = $this->input->post('etapa_data_fim') ?: null;
            }
            if (in_array('status', $campos_etapas)) {
                $etapa_data['status'] = 'pendente';
            }
            if (in_array('ativo', $campos_etapas)) {
                $etapa_data['ativo'] = 1;
            }
            if (in_array('created_at', $campos_etapas)) {
                $etapa_data['created_at'] = date('Y-m-d H:i:s');
            }
            if (in_array('updated_at', $campos_etapas)) {
                $etapa_data['updated_at'] = date('Y-m-d H:i:s');
            }

            log_message('debug', 'salvarWizard - Dados etapa: ' . print_r($etapa_data, true));

            $this->db->insert('obra_etapas', $etapa_data);

            // Verificar erro no insert
            $error = $this->db->error();
            if ($error['code'] != 0) {
                throw new Exception('Erro SQL ao criar etapa: ' . $error['message']);
            }

            $etapa_id = $this->db->insert_id();

            if (!$etapa_id) {
                throw new Exception('Erro ao criar etapa: insert_id retornou vazio');
            }

            log_message('debug', 'salvarWizard - Etapa criada com ID: ' . $etapa_id);

            // 2. Salvar atividades (se houver)
            $atividades = $this->input->post('atividades');
            $total_atividades = 0;

            if (!empty($atividades) && is_array($atividades)) {
                // Verificar campos da tabela obra_atividades
                $campos_atividades = $this->db->list_fields('obra_atividades');
                log_message('debug', 'salvarWizard - Campos obra_atividades: ' . implode(', ', $campos_atividades));

                foreach ($atividades as $atividade) {
                    if (!empty($atividade['titulo'])) {
                        $ativ_data = ['obra_id' => $obra_id];

                        if (in_array('etapa_id', $campos_atividades)) {
                            $ativ_data['etapa_id'] = $etapa_id;
                        }
                        if (in_array('titulo', $campos_atividades)) {
                            $ativ_data['titulo'] = $atividade['titulo'];
                        } elseif (in_array('descricao', $campos_atividades)) {
                            $ativ_data['descricao'] = $atividade['titulo'];
                        }
                        if (in_array('tipo', $campos_atividades)) {
                            $ativ_data['tipo'] = $atividade['tipo'] ?? 'trabalho';
                        }
                        if (in_array('status', $campos_atividades)) {
                            $ativ_data['status'] = 'agendada';
                        }
                        if (in_array('data_atividade', $campos_atividades)) {
                            $ativ_data['data_atividade'] = date('Y-m-d');
                        }
                        if (in_array('ativo', $campos_atividades)) {
                            $ativ_data['ativo'] = 1;
                        }
                        if (in_array('created_at', $campos_atividades)) {
                            $ativ_data['created_at'] = date('Y-m-d H:i:s');
                        }

                        $this->db->insert('obra_atividades', $ativ_data);
                        $total_atividades++;
                    }
                }
            }

            $this->db->trans_complete();

            // Atualizar progresso da etapa criada
            if (!empty($etapa_id) && $this->load->model('obra_atividades_model')) {
                $this->obra_atividades_model->atualizarProgressoEtapa($etapa_id);
            }

            $this->session->set_flashdata('success',
                'Etapa criada com sucesso! ' .
                ($total_atividades > 0 ? "{$total_atividades} atividade(s) adicionada(s)." : '')
            );

        } catch (Exception $e) {
            $this->db->trans_rollback();
            log_message('error', 'Erro no wizard: ' . $e->getMessage());
            $this->session->set_flashdata('error', 'Erro ao salvar: ' . $e->getMessage());
        }

        redirect('obras/visualizar/' . $obra_id);
    }

    /**
     * Editar atividade
     */
    public function editarAtividade($atividade_id)
    {
        if (!$atividade_id || !is_numeric($atividade_id)) {
            $this->session->set_flashdata('error', 'Atividade não encontrada.');
            redirect('obras');
        }

        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'eObras')) {
            $this->session->set_flashdata('error', 'Sem permissão para editar atividades.');
            redirect('obras');
        }

        $this->load->model('usuarios_model');

        $this->data['atividade'] = $this->obra_atividades_model->getById($atividade_id);

        if (!$this->data['atividade']) {
            $this->session->set_flashdata('error', 'Atividade não encontrada.');
            redirect('obras');
        }

        $obra_id = $this->data['atividade']->obra_id;

        // Carregar dados para o formulário
        $this->data['obra'] = $this->obras_model->getById($obra_id);
        $this->data['tecnicos'] = $this->usuarios_model->getAll();
        $this->data['etapas'] = $this->obras_model->getEtapas($obra_id);

        // Carregar configs dinâmicas
        $this->load->model('Atividades_tipos_model');
        $this->load->model('atividades_model');
        $this->data['tipos_atividades'] = $this->Atividades_tipos_model->listar([], true) ?? [];
        $this->data['status_atividade'] = $this->atividades_model->getStatusAtividade() ?? [];

        // Processar formulário
        if ($this->input->post()) {
            log_message('debug', 'editarAtividade - POST recebido: ' . print_r($this->input->post(), true));

            $dados = [
                'titulo' => $this->input->post('titulo'),
                'descricao' => $this->input->post('descricao'),
                'data_atividade' => $this->input->post('data_atividade'),
                'tipo' => $this->input->post('tipo') ?: 'trabalho',
                'status' => $this->input->post('status') ?: 'agendada',
                'tecnico_id' => $this->input->post('tecnico_id') ? (int)$this->input->post('tecnico_id') : null,
                'etapa_id' => $this->input->post('etapa_id') ? (int)$this->input->post('etapa_id') : null,
                'percentual_concluido' => (int)($this->input->post('percentual_concluido') ?: 0),
                'visivel_cliente' => $this->input->post('visivel_cliente') ? 1 : 0,
            ];

            log_message('debug', 'editarAtividade - Dados preparados: ' . print_r($dados, true));

            $result = $this->obra_atividades_model->update($atividade_id, $dados);
            log_message('debug', 'editarAtividade - Resultado update: ' . ($result ? 'true' : 'false'));

            if ($result) {
                $this->session->set_flashdata('success', 'Atividade atualizada com sucesso!');
                redirect('obras/visualizarAtividade/' . $atividade_id);
            } else {
                $error = $this->db->error();
                log_message('error', 'editarAtividade - Erro DB: ' . print_r($error, true));
                $this->session->set_flashdata('error', 'Erro ao atualizar atividade: ' . ($error['message'] ?? 'Erro desconhecido'));
            }
        }

        $this->data['view'] = 'obras/atividade_edit';
        return $this->layout();
    }

    /**
     * Migrar tabela de atividades - adicionar colunas faltantes
     */
    public function migrarAtividades()
    {
        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'cObras')) {
            echo 'Sem permissão';
            return;
        }

        echo '<h2>Migração - Tabela obra_atividades</h2>';
        echo '<hr>';

        // Verificar colunas existentes
        $colunas_existentes = $this->db->list_fields('obra_atividades');
        echo '<p><strong>Colunas atuais:</strong> ' . implode(', ', $colunas_existentes) . '</p>';

        // Colunas a adicionar
        $colunas_para_adicionar = [
            'titulo' => "VARCHAR(255) AFTER obra_id",
            'etapa_id' => "INT NULL AFTER titulo",
            'tecnico_id' => "INT NULL AFTER etapa_id",
            'status' => "VARCHAR(50) DEFAULT 'agendada' AFTER tipo",
            'data_atividade' => "DATE AFTER status",
            'percentual_concluido' => "INT DEFAULT 0 AFTER data_atividade",
            'visivel_cliente' => "TINYINT(1) DEFAULT 1 AFTER percentual_concluido",
            'updated_at' => "DATETIME AFTER created_at"
        ];

        $adicionadas = [];
        $existentes = [];

        foreach ($colunas_para_adicionar as $coluna => $definicao) {
            if (!in_array($coluna, $colunas_existentes)) {
                $sql = "ALTER TABLE obra_atividades ADD COLUMN {$coluna} {$definicao}";
                if ($this->db->query($sql)) {
                    $adicionadas[] = $coluna;
                }
            } else {
                $existentes[] = $coluna;
            }
        }

        echo '<h3>Resultado:</h3>';
        if (!empty($adicionadas)) {
            echo '<p style="color: green;"><strong>Colunas adicionadas:</strong> ' . implode(', ', $adicionadas) . '</p>';
        }
        if (!empty($existentes)) {
            echo '<p style="color: blue;"><strong>Já existiam:</strong> ' . implode(', ', $existentes) . '</p>';
        }

        // Atualizar registros existentes - copiar descricao para titulo
        if (in_array('descricao', $colunas_existentes) && in_array('titulo', $adicionadas)) {
            $this->db->query("UPDATE obra_atividades SET titulo = SUBSTRING(descricao, 1, 255) WHERE titulo IS NULL OR titulo = ''");
            echo '<p style="color: orange;">Registros atualizados: titulo copiado de descricao</p>';
        }

        // Atualizar registros existentes - data_atividade = created_at
        if (in_array('data_atividade', $adicionadas) && in_array('created_at', $colunas_existentes)) {
            $this->db->query("UPDATE obra_atividades SET data_atividade = DATE(created_at) WHERE data_atividade IS NULL");
            echo '<p style="color: orange;">Registros atualizados: data_atividade definida</p>';
        }

        echo '<hr>';
        echo '<a href="' . site_url('obras/atividades/3') . '">Voltar para Atividades</a>';
    }

    /**
     * Visualizar atividade
     */
    public function visualizarAtividade($atividade_id = null)
    {
        // Pegar ID do parâmetro ou do URI
        if (!$atividade_id) {
            $atividade_id = $this->uri->segment(3);
        }

        if (!$atividade_id || !is_numeric($atividade_id)) {
            $this->session->set_flashdata('error', 'Atividade não encontrada.');
            redirect('obras');
        }

        $this->data['atividade'] = $this->obra_atividades_model->getById($atividade_id);

        if (!$this->data['atividade']) {
            $this->session->set_flashdata('error', 'Atividade não encontrada.');
            redirect('obras');
        }

        // Carregar checkins model sob demanda se não estiver carregado
        if (!isset($this->obra_checkins_model)) {
            $this->load->model('obra_checkins_model');
        }

        // Carregar Atividades_model para buscar execução real do wizard
        $this->load->model('Atividades_model', 'atividades');

        $this->data['obra'] = $this->obras_model->getById($this->data['atividade']->obra_id);
        $this->data['historico'] = $this->obra_atividades_model->getHistorico($atividade_id);
        $this->data['checkins'] = $this->obra_checkins_model->getByAtividade($atividade_id);

        // Carregar configs dinâmicas
        $this->load->model('Atividades_tipos_model');
        $this->load->model('atividades_model');
        $this->data['tipos_atividades'] = $this->Atividades_tipos_model->listar([], true) ?? [];
        $this->data['status_atividade'] = $this->atividades_model->getStatusAtividade() ?? [];

        // Buscar histórico completo de execuções (incluindo reatendimentos)
        $this->data['historico_execucoes'] = $this->atividades->getHistoricoExecucoes($atividade_id);

        // Buscar atividade real (execução do wizard) vinculada a esta atividade planejada
        // A vinculação é feita pelo campo obra_atividade_id na tabela os_atividades
        $this->db->where('obra_atividade_id', $atividade_id);
        $this->db->order_by('idAtividade', 'DESC');
        $query = $this->db->get('os_atividades');
        $atividade_real = $query ? $query->row() : null;

        if ($atividade_real) {
            // Buscar dados completos da atividade real (incluindo observações)
            $this->data['atividade_real'] = $this->atividades->getByIdCompleto($atividade_real->idAtividade);

            // Mesclar observações da atividade real com a atividade planejada
            if (!empty($this->data['atividade_real']->observacoes)) {
                $this->data['atividade']->observacoes = $this->data['atividade_real']->observacoes;
            }

            // Mesclar problemas encontrados
            if (!empty($this->data['atividade_real']->problemas_encontrados)) {
                $this->data['atividade']->problemas_encontrados = $this->data['atividade_real']->problemas_encontrados;
            }

            // Mesclar solução aplicada
            if (!empty($this->data['atividade_real']->solucao_aplicada)) {
                $this->data['atividade']->solucao_aplicada = $this->data['atividade_real']->solucao_aplicada;
            }

            // Mesclar etapa da atividade real
            if (!empty($this->data['atividade_real']->etapa_nome)) {
                $this->data['atividade']->etapa_nome = $this->data['atividade_real']->etapa_nome;
            } elseif (!empty($this->data['atividade_real']->etapa_id)) {
                // Buscar nome da etapa pelo ID para atividades antigas
                $etapa = $this->db->get_where('obra_etapas', ['id' => $this->data['atividade_real']->etapa_id])->row();
                if ($etapa) {
                    $this->data['atividade']->etapa_nome = $etapa->nome;
                    $this->data['atividade_real']->etapa_nome = $etapa->nome;
                }
            }

            // Mesclar horários de início e fim da atividade real
            if (!empty($this->data['atividade_real']->hora_inicio)) {
                $this->data['atividade']->hora_inicio = $this->data['atividade_real']->hora_inicio;
            }
            if (!empty($this->data['atividade_real']->hora_fim)) {
                $this->data['atividade']->hora_fim = $this->data['atividade_real']->hora_fim;
            }

            // Calcular horas trabalhadas
            if (!empty($this->data['atividade_real']->duracao_minutos)) {
                $this->data['atividade']->horas_trabalhadas = round($this->data['atividade_real']->duracao_minutos / 60, 2);
            } elseif (!empty($this->data['atividade_real']->hora_inicio) && !empty($this->data['atividade_real']->hora_fim)) {
                $inicio = strtotime($this->data['atividade_real']->hora_inicio);
                $fim = strtotime($this->data['atividade_real']->hora_fim);
                $duracao_segundos = $fim - $inicio;
                $this->data['atividade']->horas_trabalhadas = round($duracao_segundos / 3600, 2);
            }

            // Buscar checkins da atividade real também
            $checkins_real = $this->obra_checkins_model->getByAtividade($atividade_real->idAtividade);
            if (!empty($checkins_real)) {
                // Mesclar checkins
                $this->data['checkins'] = array_merge($this->data['checkins'], $checkins_real);
            }

            // Buscar fotos da atividade real
            $fotos = $this->atividades->getFotos($atividade_real->idAtividade);

            // Determinar se a atividade e um impedimento
            $atividade_plano = $this->obra_atividades_model->getById($atividade_id);
            $tem_impedimento = $atividade_plano && !empty($atividade_plano->impedimento) && $atividade_plano->impedimento == 1;

            // Se for impedimento, sobrescrever tipo de todas as fotos da execucao
            if ($tem_impedimento && !empty($fotos)) {
                foreach ($fotos as $f) {
                    $f->tipo_foto = 'impedimento';
                }
            }

            // Adicionar foto do checkin/checkout da os_atividades
            if (!empty($atividade_real->foto_checkin)) {
                $f = new stdClass();
                $f->caminho_arquivo = $atividade_real->foto_checkin;
                $f->tipo_foto = $tem_impedimento ? 'impedimento' : 'checkin';
                $f->foto_base64 = null;
                $fotos[] = $f;
            }
            if (!empty($atividade_real->foto_checkout)) {
                $f = new stdClass();
                $f->caminho_arquivo = $atividade_real->foto_checkout;
                $f->tipo_foto = 'checkout';
                $f->foto_base64 = null;
                $fotos[] = $f;
            }
        } else {
            $fotos = [];
            $atividade_plano = $this->obra_atividades_model->getById($atividade_id);
            $tem_impedimento = $atividade_plano && !empty($atividade_plano->impedimento) && $atividade_plano->impedimento == 1;
        }

        // Buscar fotos JSON da obra_atividades (checkin, atividade, checkout)
        // Sempre buscar, mesmo sem os_atividades vinculada (ex: upload pelo portal do tecnico)
        if ($atividade_plano) {
            $json_fields = ['fotos_checkin', 'fotos_atividade', 'fotos_checkout'];
            foreach ($json_fields as $field) {
                if (!empty($atividade_plano->$field)) {
                    $decoded = json_decode($atividade_plano->$field, true);
                    if (is_array($decoded)) {
                        foreach ($decoded as $path) {
                            $f = new stdClass();
                            $f->caminho_arquivo = $path;
                            if ($tem_impedimento) {
                                $f->tipo_foto = 'impedimento';
                            } else {
                                $f->tipo_foto = ($field === 'fotos_checkin') ? 'checkin' : (($field === 'fotos_checkout') ? 'checkout' : 'execucao');
                            }
                            $f->foto_base64 = null;
                            $fotos[] = $f;
                        }
                    }
                }
            }
        }

        $this->data['fotos_atividade'] = $fotos;

        $this->data['view'] = 'obras/atividade_view';

        return $this->layout();
    }

    /**
     * Imprimir relatório da atividade para o cliente
     */
    public function imprimirAtividade($atividade_id = null)
    {
        if (!$atividade_id || !is_numeric($atividade_id)) {
            $atividade_id = $this->uri->segment(3);
        }

        if (!$atividade_id || !is_numeric($atividade_id)) {
            show_error('Atividade não encontrada.');
            return;
        }

        $this->load->model('mapos_model');
        $this->load->model('Atividades_model', 'atividades');

        if (!isset($this->obra_checkins_model)) {
            $this->load->model('obra_checkins_model');
        }

        $atividade = $this->obra_atividades_model->getById($atividade_id);
        if (!$atividade) {
            show_error('Atividade não encontrada.');
            return;
        }

        $obra = $this->obras_model->getById($atividade->obra_id);
        $historico = $this->obra_atividades_model->getHistorico($atividade_id);
        $checkins = $this->obra_checkins_model->getByAtividade($atividade_id);
        $emitente = $this->mapos_model->getEmitente();
        $cliente = $this->obras_model->getCliente($atividade->obra_id);
        $historico_execucoes = $this->atividades->getHistoricoExecucoes($atividade_id);

        $this->db->where('obra_atividade_id', $atividade_id);
        $this->db->order_by('idAtividade', 'DESC');
        $query = $this->db->get('os_atividades');
        $atividade_real = $query ? $query->row() : null;

        $fotos_atividade = [];
        if ($atividade_real) {
            $atividade_real_completa = $this->atividades->getByIdCompleto($atividade_real->idAtividade);

            // Mesclar observações da atividade real com a planejada
            if (!empty($atividade_real_completa->observacoes)) {
                $atividade->observacoes = $atividade_real_completa->observacoes;
            }
            if (!empty($atividade_real_completa->problemas_encontrados)) {
                $atividade->problemas_encontrados = $atividade_real_completa->problemas_encontrados;
            }
            if (!empty($atividade_real_completa->solucao_aplicada)) {
                $atividade->solucao_aplicada = $atividade_real_completa->solucao_aplicada;
            }
            if (!empty($atividade_real_completa->etapa_nome)) {
                $atividade->etapa_nome = $atividade_real_completa->etapa_nome;
            } elseif (!empty($atividade_real_completa->etapa_id)) {
                $etapa = $this->db->get_where('obra_etapas', ['id' => $atividade_real_completa->etapa_id])->row();
                if ($etapa) {
                    $atividade->etapa_nome = $etapa->nome;
                }
            }
            if (!empty($atividade_real_completa->hora_inicio)) {
                $atividade->hora_inicio = $atividade_real_completa->hora_inicio;
            }
            if (!empty($atividade_real_completa->hora_fim)) {
                $atividade->hora_fim = $atividade_real_completa->hora_fim;
            }
            if (!empty($atividade_real_completa->duracao_minutos)) {
                $atividade->horas_trabalhadas = round($atividade_real_completa->duracao_minutos / 60, 2);
            } elseif (!empty($atividade_real_completa->hora_inicio) && !empty($atividade_real_completa->hora_fim)) {
                $inicio = strtotime($atividade_real_completa->hora_inicio);
                $fim = strtotime($atividade_real_completa->hora_fim);
                $atividade->horas_trabalhadas = round(($fim - $inicio) / 3600, 2);
            }

            $checkins_real = $this->obra_checkins_model->getByAtividade($atividade_real->idAtividade);
            if (!empty($checkins_real)) {
                $checkins = array_merge($checkins, $checkins_real);
            }

            $fotos_atividade = $this->atividades->getFotos($atividade_real->idAtividade);

            // Determinar se a atividade e um impedimento
            $atividade_plano = $this->obra_atividades_model->getById($atividade_id);
            $tem_impedimento = $atividade_plano && !empty($atividade_plano->impedimento) && $atividade_plano->impedimento == 1;

            // Se for impedimento, sobrescrever tipo de todas as fotos da execucao
            if ($tem_impedimento && !empty($fotos_atividade)) {
                foreach ($fotos_atividade as $f) {
                    $f->tipo_foto = 'impedimento';
                }
            }

            // Adicionar foto do checkin/checkout da os_atividades
            if (!empty($atividade_real->foto_checkin)) {
                $f = new stdClass();
                $f->caminho_arquivo = $atividade_real->foto_checkin;
                $f->tipo_foto = $tem_impedimento ? 'impedimento' : 'checkin';
                $f->foto_base64 = null;
                $fotos_atividade[] = $f;
            }
            if (!empty($atividade_real->foto_checkout)) {
                $f = new stdClass();
                $f->caminho_arquivo = $atividade_real->foto_checkout;
                $f->tipo_foto = 'checkout';
                $f->foto_base64 = null;
                $fotos_atividade[] = $f;
            }
        } else {
            $fotos_atividade = [];
            $atividade_plano = $this->obra_atividades_model->getById($atividade_id);
            $tem_impedimento = $atividade_plano && !empty($atividade_plano->impedimento) && $atividade_plano->impedimento == 1;
        }

        // Buscar fotos JSON da obra_atividades (checkin, atividade, checkout)
        // Sempre buscar, mesmo sem os_atividades vinculada (ex: upload pelo portal do tecnico)
        if ($atividade_plano) {
            $json_fields = ['fotos_checkin', 'fotos_atividade', 'fotos_checkout'];
            foreach ($json_fields as $field) {
                if (!empty($atividade_plano->$field)) {
                    $decoded = json_decode($atividade_plano->$field, true);
                    if (is_array($decoded)) {
                        foreach ($decoded as $path) {
                            $f = new stdClass();
                            $f->caminho_arquivo = $path;
                            if ($tem_impedimento) {
                                $f->tipo_foto = 'impedimento';
                            } else {
                                $f->tipo_foto = ($field === 'fotos_checkin') ? 'checkin' : (($field === 'fotos_checkout') ? 'checkout' : 'execucao');
                            }
                            $f->foto_base64 = null;
                            $fotos_atividade[] = $f;
                        }
                    }
                }
            }
        }

        // Carregar configs dinâmicas
        $this->load->model('Atividades_tipos_model');
        $this->load->model('atividades_model');
        $tipos_atividades = $this->Atividades_tipos_model->listar([], true) ?? [];
        $status_atividade = $this->atividades_model->getStatusAtividade() ?? [];

        $data = [
            'atividade' => $atividade,
            'obra' => $obra,
            'historico' => $historico,
            'checkins' => $checkins,
            'emitente' => $emitente,
            'cliente' => $cliente,
            'historico_execucoes' => $historico_execucoes,
            'fotos_atividade' => $fotos_atividade,
            'atividade_real' => $atividade_real_completa ?? null,
            'tipos_atividades' => $tipos_atividades,
            'status_atividade' => $status_atividade,
        ];

        $this->load->view('obras/atividade_print', $data);
    }

    /**
     * Atualizar status de uma atividade
     */
    public function atualizarStatusAtividade($atividade_id = null)
    {
        if (!$atividade_id || !is_numeric($atividade_id)) {
            $this->session->set_flashdata('error', 'Atividade não encontrada.');
            redirect('obras');
        }

        $novo_status = $this->input->post('novo_status');
        $observacao = $this->input->post('observacao_status');

        // Validar status permitidos (incluindo reaberta para reatendimento)
        $status_permitidos = ['agendada', 'iniciada', 'pausada', 'concluida', 'cancelada', 'reaberta'];
        if (!in_array($novo_status, $status_permitidos)) {
            $this->session->set_flashdata('error', 'Status inválido.');
            redirect('obras/visualizarAtividade/' . $atividade_id);
        }

        // Buscar atividade
        $atividade = $this->obra_atividades_model->getById($atividade_id);
        if (!$atividade) {
            $this->session->set_flashdata('error', 'Atividade não encontrada.');
            redirect('obras');
        }

        // Preparar dados para atualização
        $dados = ['status' => $novo_status];

        // Se estiver reabrindo (concluida/cancelada -> agendada/iniciada/reaberta), limpar datas de conclusão e criar reatendimento
        if (in_array($novo_status, ['agendada', 'iniciada', 'reaberta']) && in_array($atividade->status, ['concluida', 'cancelada', 'reaberta'])) {
            $dados['data_conclusao'] = null;
            $dados['percentual_concluido'] = 0;
            $dados['hora_fim'] = null;
            $dados['hora_inicio'] = null;
            $dados['horas_trabalhadas'] = 0;

            // Criar registro de reatendimento - preservar histórico da execução anterior
            $this->load->model('atividades_model');

            // Buscar o técnico da última execução da atividade para atribuir o reatendimento a ele
            $ultimaExecucao = $this->atividades_model->getUltimaExecucao($atividade_id);
            $tecnico_id = $ultimaExecucao ? $ultimaExecucao->tecnico_id : $atividade->tecnico_id;

            $reatendimento_id = $this->atividades_model->criarReatendimento([
                'obra_atividade_id' => $atividade_id,
                'obra_id' => $atividade->obra_id,
                'etapa_id' => $atividade->etapa_id,
                'titulo' => $atividade->titulo ?? 'Reatendimento #' . $atividade_id,
                'descricao' => 'Reatendimento da atividade reaberta',
                'status' => 'reaberta',
                'motivo_reabertura' => $observacao ?? 'Reabertura para reexecução',
                'tecnico_id' => $tecnico_id, // Atribuir automaticamente ao técnico da execução anterior
            ]);

            // Atualizar o técnico da obra_atividade para o mesmo técnico do reatendimento
            if ($tecnico_id) {
                $this->obra_atividades_model->update($atividade_id, ['tecnico_id' => $tecnico_id]);
            }

            if ($reatendimento_id) {
                $this->session->set_flashdata('success', 'Atividade reaberta com sucesso! Um novo reatendimento foi criado e atribuído ao técnico responsável.');
            } else {
                $this->session->set_flashdata('success', 'Atividade reaberta com sucesso!');
            }
        } else {
            // Registrar no histórico
            $status_labels = [
                'agendada' => 'Agendada',
                'iniciada' => 'Em Execução',
                'pausada' => 'Pausada',
                'concluida' => 'Concluída',
                'cancelada' => 'Cancelada',
                'reaberta' => 'Reaberta (Reatendimento)'
            ];

            $descricao = 'Status alterado para: ' . ($status_labels[$novo_status] ?? $novo_status);
            if ($observacao) {
                $descricao .= '. Observação: ' . $observacao;
            }

            $this->obra_atividades_model->adicionarHistorico($atividade_id, 'status_alterado', $descricao);
            $this->session->set_flashdata('success', 'Status atualizado com sucesso!');
        }

        // Atualizar atividade
        $result = $this->obra_atividades_model->update($atividade_id, $dados);

        if (!$result) {
            $this->session->set_flashdata('error', 'Erro ao atualizar status.');
        } else {
            // Atualizar progresso da obra quando status muda
            if ($atividade->obra_id) {
                // Se atividade foi concluída ou teve progresso alterado, recalcular
                if ($novo_status === 'concluida' || isset($dados['percentual_concluido'])) {
                    $this->obras_model->atualizarProgressoPorAtividades($atividade->obra_id);
                    log_info('Progresso da obra ' . $atividade->obra_id . ' atualizado após alteração na atividade ' . $atividade_id);
                }
            }
        }

        redirect('obras/visualizarAtividade/' . $atividade_id);
    }

    /**
     * API: Recalcular e atualizar progresso da obra
     */
    public function api_atualizarProgresso($obra_id)
    {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        if (!$obra_id || !is_numeric($obra_id)) {
            echo json_encode(['success' => false, 'message' => 'ID da obra inválido']);
            return;
        }

        // Calcular progresso baseado nas atividades
        $progresso = $this->obras_model->atualizarProgressoPorAtividades($obra_id);

        if ($progresso !== false) {
            echo json_encode([
                'success' => true,
                'progresso' => $progresso,
                'message' => 'Progresso atualizado com sucesso'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Erro ao atualizar progresso'
            ]);
        }
    }

    /**
     * API: Recalcular progresso de todas as obras
     */
    public function api_atualizarProgressoGeral()
    {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'eObras')) {
            echo json_encode(['success' => false, 'message' => 'Sem permissão']);
            return;
        }

        try {
            $obras = $this->obras_model->getAll();
            $atualizadas = 0;
            $erros = 0;

            foreach ($obras as $obra) {
                $result = $this->obras_model->atualizarProgressoPorAtividades($obra->id);
                if ($result !== false) {
                    $atualizadas++;
                } else {
                    $erros++;
                }
            }

            echo json_encode([
                'success' => true,
                'atualizadas' => $atualizadas,
                'erros' => $erros,
                'message' => $atualizadas . ' obras atualizadas com sucesso!'
            ]);
        } catch (Exception $e) {
            log_message('error', 'Erro ao recalcular progressos gerais: ' . $e->getMessage());
            echo json_encode([
                'success' => false,
                'message' => 'Erro ao recalcular progressos: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Iniciar um reatendimento (reatendimento com status 'reaberta' -> 'em_andamento')
     */
    public function iniciarReatendimento($reatendimento_id = null)
    {
        // Verificar se é requisição AJAX
        $is_ajax = $this->input->is_ajax_request();

        if (!$reatendimento_id || !is_numeric($reatendimento_id)) {
            if ($is_ajax) {
                $this->output->json(['success' => false, 'message' => 'Reatendimento não encontrado.']);
                return;
            }
            $this->session->set_flashdata('error', 'Reatendimento não encontrado.');
            redirect('obras');
        }

        $this->load->model('atividades_model');

        $reatendimento = $this->atividades_model->getById($reatendimento_id);
        if (!$reatendimento) {
            if ($is_ajax) {
                $this->output->json(['success' => false, 'message' => 'Reatendimento não encontrado.']);
                return;
            }
            $this->session->set_flashdata('error', 'Reatendimento não encontrado.');
            redirect('obras');
        }

        // Verificar se está no status correto
        if ($reatendimento->status !== 'reaberta') {
            if ($is_ajax) {
                $this->output->json(['success' => false, 'message' => 'Este reatendimento não pode ser iniciado. Status atual: ' . $reatendimento->status]);
                return;
            }
            $this->session->set_flashdata('error', 'Este reatendimento não pode ser iniciado. Status atual: ' . $reatendimento->status);
            redirect('obras/visualizarAtividade/' . $reatendimento->obra_atividade_id);
        }

        // Verificar se o técnico logado é o técnico atribuído ao reatendimento
        $tecnico_id = $this->session->userdata('tec_id') ?? $this->session->userdata('idUsuario');
        if ($reatendimento->tecnico_id && $reatendimento->tecnico_id != $tecnico_id) {
            if ($is_ajax) {
                $this->output->json(['success' => false, 'message' => 'Este reatendimento está atribuído a outro técnico.']);
                return;
            }
            $this->session->set_flashdata('error', 'Este reatendimento está atribuído a outro técnico.');
            redirect('obras/visualizarAtividade/' . $reatendimento->obra_atividade_id);
        }

        // Iniciar o reatendimento
        $result = $this->atividades_model->iniciarReatendimento($reatendimento_id, $tecnico_id ?? 1);

        if ($is_ajax) {
            if ($result) {
                $this->output->json(['success' => true, 'message' => 'Reatendimento iniciado com sucesso!', 'status' => 'success']);
            } else {
                $this->output->json(['success' => false, 'message' => 'Erro ao iniciar o reatendimento.']);
            }
            return;
        }

        if ($result) {
            $this->session->set_flashdata('success', 'Reatendimento iniciado com sucesso! A atividade está agora em execução.');
        } else {
            $this->session->set_flashdata('error', 'Erro ao iniciar o reatendimento.');
        }

        redirect('obras/visualizarAtividade/' . $reatendimento->obra_atividade_id);
    }

    // ============================================
    // RELATÓRIOS
    // ============================================

    /**
     * Relatório de progresso
     */
    public function relatorioProgresso($obra_id)
    {
        if (!$obra_id || !is_numeric($obra_id)) {
            $this->session->set_flashdata('error', 'Obra não encontrada.');
            redirect('obras');
        }

        $this->load->model('mapos_model');

        $this->data['obra'] = $this->obras_model->getByIdCompleto($obra_id);
        $this->data['etapas'] = $this->obras_model->getEtapasComEstatisticas($obra_id);
        $this->data['estatisticas'] = $this->obra_atividades_model->getEstatisticas($obra_id);
        $this->data['status_obra'] = $this->obras_model->getStatusObra() ?? [];
        $this->data['status_atividade'] = [];
        if (file_exists(APPPATH . 'models/atividades_model.php')) {
            $this->load->model('atividades_model');
            $this->data['status_atividade'] = $this->atividades_model->getStatusAtividade() ?? [];
        }
        $this->data['emitente'] = $this->mapos_model->getEmitente();
        $this->data['view'] = 'obras/relatorios/progresso';

        return $this->layout();
    }

    /**
     * Relatório diário
     */
    public function relatorioDiario($obra_id)
    {
        if (!$obra_id || !is_numeric($obra_id)) {
            $this->session->set_flashdata('error', 'Obra não encontrada.');
            redirect('obras');
        }

        $data = $this->input->get('data') ?: date('Y-m-d');

        $this->data['obra'] = $this->obras_model->getById($obra_id);
        $this->data['data_relatorio'] = $data;
        $this->data['atividades'] = $this->obra_atividades_model->getByObra($obra_id, [
            'data_inicio' => $data,
            'data_fim' => $data
        ]);
        $this->data['status_obra'] = $this->obras_model->getStatusObra() ?? [];
        $this->data['status_atividade'] = [];
        if (file_exists(APPPATH . 'models/atividades_model.php')) {
            $this->load->model('atividades_model');
            $this->data['status_atividade'] = $this->atividades_model->getStatusAtividade() ?? [];
        }
        $this->data['view'] = 'obras/relatorios/diario';

        return $this->layout();
    }

    /**
     * Relatório Geral da Obra
     */
    public function relatorioGeral($obra_id)
    {
        if (!$obra_id || !is_numeric($obra_id)) {
            $this->session->set_flashdata('error', 'Obra não encontrada.');
            redirect('obras');
        }

        $this->load->model('mapos_model');
        $this->load->model('usuarios_model');

        // Dados da obra
        $this->data['obra'] = $this->obras_model->getByIdCompleto($obra_id);

        if (!$this->data['obra']) {
            $this->session->set_flashdata('error', 'Obra não encontrada.');
            redirect('obras');
        }

        // Estatísticas
        $this->data['estatisticas'] = $this->obra_atividades_model->getEstatisticas($obra_id);

        // Etapas com estatísticas
        $this->data['etapas'] = $this->obras_model->getEtapasComEstatisticas($obra_id);

        // Equipe
        $this->data['equipe'] = $this->obras_model->getEquipe($obra_id);

        // Atividades do sistema antigo
        $this->data['atividades'] = $this->obra_atividades_model->getByObra($obra_id, [], 100);

        // Atividades do novo sistema (Hora Início/Fim)
        if (file_exists(APPPATH . 'models/Atividades_model.php')) {
            $this->load->model('Atividades_model', 'atividades_novas');
            $this->data['atividades_sistema'] = $this->atividades_novas->listarPorObra($obra_id, [], 50);
            $this->data['estatisticas_atividades'] = $this->atividades_novas->getEstatisticasPorObra($obra_id);
        } else {
            $this->data['atividades_sistema'] = [];
            $this->data['estatisticas_atividades'] = null;
        }

        // Emitente para cabeçalho
        $this->data['status_obra'] = $this->obras_model->getStatusObra() ?? [];
        $this->data['status_atividade'] = [];
        if (file_exists(APPPATH . 'models/atividades_model.php')) {
            $this->load->model('atividades_model');
            $this->data['status_atividade'] = $this->atividades_model->getStatusAtividade() ?? [];
        }
        $this->data['emitente'] = $this->mapos_model->getEmitente();

        $this->data['view'] = 'obras/relatorios/geral';

        return $this->layout();
    }

    /**
     * Relatório Geral em formato de impressão (abre em nova janela)
     */
    public function imprimirRelatorio($obra_id)
    {
        if (!$obra_id || !is_numeric($obra_id)) {
            $this->session->set_flashdata('error', 'Obra não encontrada.');
            redirect('obras');
        }

        $this->load->model('mapos_model');
        $this->load->model('usuarios_model');

        // Dados da obra
        $this->data['obra'] = $this->obras_model->getByIdCompleto($obra_id);

        if (!$this->data['obra']) {
            $this->session->set_flashdata('error', 'Obra não encontrada.');
            redirect('obras');
        }

        // Estatísticas
        $this->data['estatisticas'] = $this->obra_atividades_model->getEstatisticas($obra_id);

        // Etapas com estatísticas
        $this->data['etapas'] = $this->obras_model->getEtapasComEstatisticas($obra_id);

        // Equipe
        $this->data['equipe'] = $this->obras_model->getEquipe($obra_id);

        // Atividades do sistema antigo
        $this->data['atividades'] = $this->obra_atividades_model->getByObra($obra_id, [], 100);

        // Atividades do novo sistema (Hora Início/Fim)
        if (file_exists(APPPATH . 'models/Atividades_model.php')) {
            $this->load->model('Atividades_model', 'atividades_novas');
            $this->data['atividades_sistema'] = $this->atividades_novas->listarPorObra($obra_id, [], 50);
            $this->data['estatisticas_atividades'] = $this->atividades_novas->getEstatisticasPorObra($obra_id);
        } else {
            $this->data['atividades_sistema'] = [];
            $this->data['estatisticas_atividades'] = null;
        }

        // Emitente para cabeçalho
        $this->data['status_obra'] = $this->obras_model->getStatusObra() ?? [];
        $this->data['emitente'] = $this->mapos_model->getEmitente();

        // Carregar view de impressão (sem layout)
        $this->load->view('obras/relatorios/geral_print', $this->data);
    }

    // ============================================
    // API AJAX
    // ============================================

    /**
     * AJAX: Atualizar status da obra (edição rápida)
     */
    public function ajax_atualizar_status()
    {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        // Verificar permissão
        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'eObras')) {
            echo json_encode([
                'success' => false,
                'message' => 'Sem permissão para editar obras'
            ]);
            return;
        }

        $obra_id = $this->input->post('obra_id');
        $novo_status = $this->input->post('status');

        // Validar dados
        if (!$obra_id || !is_numeric($obra_id)) {
            echo json_encode([
                'success' => false,
                'message' => 'ID da obra inválido'
            ]);
            return;
        }

        if (!$novo_status) {
            echo json_encode([
                'success' => false,
                'message' => 'Status não informado'
            ]);
            return;
        }

        // Status permitidos
        $status_permitidos = ['prospeccao', 'contratada', 'em-andamento', 'paralisada', 'concluida', 'cancelada'];
        if (!in_array($novo_status, $status_permitidos)) {
            echo json_encode([
                'success' => false,
                'message' => 'Status inválido: ' . $novo_status
            ]);
            return;
        }

        // Atualizar status
        $dados = [
            'status' => $novo_status,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        if ($this->obras_model->update($obra_id, $dados)) {
            log_info('Status da obra atualizado. ID: ' . $obra_id . ' - Novo status: ' . $novo_status);

            // Notificar cliente se obra foi concluída
            if ($novo_status === 'concluida') {
                try {
                    require_once APPPATH . 'libraries/Email/EmailQueue.php';
                    require_once APPPATH . 'libraries/Email/TemplateEngine.php';

                    $obra = $this->obras_model->getById($obra_id);
                    if ($obra && !empty($obra->cliente_email)) {
                        $queue = new \Libraries\Email\EmailQueue();
                        $templates = new \Libraries\Email\TemplateEngine();

                        // Template configurado
                        $this->db->where('config', 'email_template_obra_concluida');
                        $templateRow = $this->db->get('configuracoes')->row();
                        $template = $templateRow && !empty($templateRow->valor) ? $templateRow->valor : 'obra_concluida';

                        // CC/BCC padrao
                        $cc = [];
                        $bcc = [];
                        $this->db->where('config', 'email_cc_default');
                        $rowCc = $this->db->get('configuracoes')->row();
                        if ($rowCc && !empty($rowCc->valor)) {
                            $cc = array_map('trim', explode(',', $rowCc->valor));
                        }
                        $this->db->where('config', 'email_bcc_default');
                        $rowBcc = $this->db->get('configuracoes')->row();
                        if ($rowBcc && !empty($rowBcc->valor)) {
                            $bcc = array_map('trim', explode(',', $rowBcc->valor));
                        }

                        $templateData = [
                            'cliente_nome' => $obra->cliente_nome ?? '',
                            'cliente_email' => $obra->cliente_email ?? '',
                            'os_titulo' => $obra->nome ?? 'Obra',
                            'os_descricao' => $obra->observacoes ?? '',
                            'os_status' => 'Concluída',
                            'os_data_criacao' => isset($obra->data_inicio_contrato) ? date('d/m/Y', strtotime($obra->data_inicio_contrato)) : date('d/m/Y'),
                            'os_link_visualizar' => base_url('obras/visualizar/' . $obra_id),
                        ];

                        $rendered = $templates->render($template, $templateData);

                        $enqueueData = [
                            'to' => $obra->cliente_email,
                            'to_name' => $obra->cliente_nome ?? '',
                            'subject' => 'Obra Concluída - ' . $obra->nome,
                            'body_html' => $rendered['html'],
                            'body_text' => $rendered['text'] ?? strip_tags($rendered['html']),
                            'template' => $template,
                            'template_data' => $templateData,
                            'priority' => 2,
                        ];
                        if (!empty($cc)) {
                            $enqueueData['cc'] = $cc;
                        }
                        if (!empty($bcc)) {
                            $enqueueData['bcc'] = $bcc;
                        }

                        $queue->enqueue($enqueueData);
                    }
                } catch (\Exception $e) {
                    log_message('error', '[Obras] Erro ao enfileirar email V5 (concluida): ' . $e->getMessage());
                }
            }

            echo json_encode([
                'success' => true,
                'message' => 'Status atualizado com sucesso',
                'obra_id' => $obra_id,
                'status' => $novo_status
            ]);
        } else {
            $error = $this->db->error();
            log_message('error', 'Erro ao atualizar status da obra: ' . print_r($error, true));
            echo json_encode([
                'success' => false,
                'message' => 'Erro ao atualizar status no banco de dados'
            ]);
        }
    }

    /**
     * API: Dados para gráfico
     */
    public function api_dadosGrafico($obra_id)
    {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        $etapas = $this->obras_model->getEtapas($obra_id);
        $dados = [];

        foreach ($etapas as $etapa) {
            $dados[] = [
                'nome' => $etapa->nome,
                'progresso' => $etapa->percentual_concluido
            ];
        }

        echo json_encode($dados);
    }

    /**
     * API: Buscar dados do cliente
     */
    public function api_getCliente($cliente_id)
    {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        $this->load->model('clientes_model');
        $cliente = $this->clientes_model->getById($cliente_id);

        if ($cliente) {
            echo json_encode([
                'success' => true,
                'cliente' => [
                    'id' => $cliente->idClientes,
                    'nome' => $cliente->nomeCliente,
                    'documento' => $cliente->documento,
                    'endereco' => $cliente->rua,
                    'numero' => $cliente->numero,
                    'bairro' => $cliente->bairro,
                    'cidade' => $cliente->cidade,
                    'estado' => $cliente->estado,
                    'cep' => $cliente->cep
                ]
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Cliente não encontrado']);
        }
    }

    /**
     * API: Buscar detalhes da atividade (para modal)
     */
    public function api_getAtividade($atividade_id)
    {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        $atividade = $this->obra_atividades_model->getById($atividade_id);

        if (!$atividade) {
            echo json_encode(['success' => false, 'message' => 'Atividade não encontrada']);
            return;
        }

        // Buscar dados do sistema novo (execução real) se existir
        $execucao_real = null;
        if (file_exists(APPPATH . 'models/Atividades_model.php')) {
            $this->load->model('Atividades_model', 'atividades_execucao');
            $this->db->where('obra_atividade_id', $atividade_id);
            $this->db->order_by('idAtividade', 'DESC');
            $query = $this->db->get('os_atividades');
            if ($query && $query->num_rows() > 0) {
                $execucao = $query->row();
                $execucao_real = $this->atividades_execucao->getByIdCompleto($execucao->idAtividade);
            }
        }

        echo json_encode([
            'success' => true,
            'atividade' => $atividade,
            'execucao_real' => $execucao_real
        ]);
    }

    /**
     * API: Salvar edição da atividade
     */
    public function api_salvarAtividade()
    {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        $atividade_id = $this->input->post('id');
        if (!$atividade_id) {
            echo json_encode(['success' => false, 'message' => 'ID da atividade não informado']);
            return;
        }

        // Verificar permissão
        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'eObras')) {
            echo json_encode(['success' => false, 'message' => 'Sem permissão para editar']);
            return;
        }

        $dados = [
            'titulo' => $this->input->post('titulo'),
            'descricao' => $this->input->post('descricao'),
            'tipo' => $this->input->post('tipo'),
            'status' => $this->input->post('status'),
            'data_atividade' => $this->input->post('data_atividade'),
            'hora_inicio' => $this->input->post('hora_inicio') ?: null,
            'hora_fim' => $this->input->post('hora_fim') ?: null,
            'percentual_concluido' => $this->input->post('percentual_concluido') ?: 0,
            'tecnico_id' => $this->input->post('tecnico_id') ?: null,
            'etapa_id' => $this->input->post('etapa_id') ?: null,
        ];

        // Remover campos nulos
        $dados = array_filter($dados, function($v) { return $v !== null; });

        $result = $this->obra_atividades_model->update($atividade_id, $dados);

        if ($result) {
            echo json_encode(['success' => true, 'message' => 'Atividade atualizada com sucesso']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao atualizar atividade']);
        }
    }

    /**
     * Diagnóstico da atividade - debug
     */
    public function diagnosticoAtividade($atividade_id = null)
    {
        if (!$atividade_id) {
            $atividade_id = $this->uri->segment(3);
        }

        if (!$atividade_id || !is_numeric($atividade_id)) {
            echo 'ID da atividade inválido';
            return;
        }

        // Carregar model
        $this->load->model('Atividades_model', 'atividades');

        // Buscar atividade planejada
        $this->data['atividade'] = $this->obra_atividades_model->getById($atividade_id);
        $this->data['atividade_id'] = $atividade_id;

        // Buscar atividade real
        $this->db->where('obra_atividade_id', $atividade_id);
        $this->db->order_by('idAtividade', 'DESC');
        $query = $this->db->get('os_atividades');
        $atividade_real_row = $query ? $query->row() : null;

        if ($atividade_real_row) {
            $this->data['atividade_real'] = $this->atividades->getByIdCompleto($atividade_real_row->idAtividade);
        } else {
            $this->data['atividade_real'] = null;
        }

        // Colunas da tabela
        $this->data['colunas'] = $this->db->list_fields('os_atividades');

        // Query executada
        $this->data['last_query'] = $this->db->last_query();

        $this->data['view'] = 'obras/diagnostico_atividade';
        return $this->layout();
    }

    // ============================================
    // CONFIGURACOES - FUNCOES DA EQUIPE
    // ============================================

    public function salvarFuncao()
    {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'cObras')) {
            echo json_encode(['success' => false, 'message' => 'Sem permissão']);
            return;
        }

        $dados = [
            'id' => $this->input->post('id') ?: null,
            'nome' => $this->input->post('nome'),
            'descricao' => $this->input->post('descricao'),
            'nivel' => $this->input->post('nivel') ?: 'baixo',
        ];

        if (empty($dados['nome'])) {
            echo json_encode(['success' => false, 'message' => 'Nome da função é obrigatório']);
            return;
        }

        // Verificar duplicata
        if (empty($dados['id'])) {
            $existe = $this->db->where('nome', $dados['nome'])->where('ativo', 1)->count_all_results('obra_funcoes');
            if ($existe > 0) {
                echo json_encode(['success' => false, 'message' => 'Já existe uma função com o nome "' . $dados['nome'] . '"']);
                return;
            }
        } else {
            $this->db->where('nome', $dados['nome']);
            $this->db->where('id !=', $dados['id']);
            $this->db->where('ativo', 1);
            $existe = $this->db->count_all_results('obra_funcoes');
            if ($existe > 0) {
                echo json_encode(['success' => false, 'message' => 'Já existe outra função com o nome "' . $dados['nome'] . '"']);
                return;
            }
        }

        $result = $this->obras_model->salvarFuncao($dados);
        $dbError = $this->db->error();

        if ($result) {
            echo json_encode(['success' => true, 'message' => 'Função salva com sucesso', 'id' => $result]);
        } else {
            $msg = 'Erro ao salvar função';
            if ($dbError && !empty($dbError['message'])) {
                if (strpos($dbError['message'], 'Duplicate') !== false && strpos($dbError['message'], 'uk_nome') !== false) {
                    $msg = 'Já existe uma função com este nome';
                }
            }
            echo json_encode(['success' => false, 'message' => $msg]);
        }
    }

    public function excluirFuncao()
    {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'dObras')) {
            echo json_encode(['success' => false, 'message' => 'Sem permissão']);
            return;
        }

        $id = $this->input->post('id');
        if (!$id || !is_numeric($id)) {
            echo json_encode(['success' => false, 'message' => 'ID inválido']);
            return;
        }

        $result = $this->obras_model->excluirFuncao($id);

        if ($result) {
            echo json_encode(['success' => true, 'message' => 'Função excluída com sucesso']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao excluir função']);
        }
    }

    // ============================================
    // CONFIGURACOES - TIPOS DE OBRA
    // ============================================

    public function salvarTipoObra()
    {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'cObras')) {
            echo json_encode(['success' => false, 'message' => 'Sem permissão']);
            return;
        }

        $dados = [
            'id' => $this->input->post('id') ?: null,
            'nome' => $this->input->post('nome'),
            'descricao' => $this->input->post('descricao'),
            'cor' => $this->input->post('cor') ?: '#3498db',
            'icone' => $this->input->post('icone') ?: 'bx-building',
        ];

        log_message('debug', 'salvarTipoObra - dados recebidos: ' . print_r($dados, true));

        if (empty($dados['nome'])) {
            echo json_encode(['success' => false, 'message' => 'Nome do tipo é obrigatório']);
            return;
        }

        // Verificar duplicata em insert
        if (empty($dados['id'])) {
            $existe = $this->db->where('nome', $dados['nome'])->where('ativo', 1)->count_all_results('obra_tipos');
            if ($existe > 0) {
                echo json_encode(['success' => false, 'message' => 'Já existe um tipo de obra com o nome "' . $dados['nome'] . '"']);
                return;
            }
        } else {
            // Verificar duplicata em update (exceto o proprio registro)
            $this->db->where('nome', $dados['nome']);
            $this->db->where('id !=', $dados['id']);
            $this->db->where('ativo', 1);
            $existe = $this->db->count_all_results('obra_tipos');
            if ($existe > 0) {
                echo json_encode(['success' => false, 'message' => 'Já existe outro tipo de obra com o nome "' . $dados['nome'] . '"']);
                return;
            }
        }

        $result = $this->obras_model->salvarTipoObra($dados);
        $dbError = $this->db->error();
        log_message('debug', 'salvarTipoObra - resultado: ' . var_export($result, true) . ' db_error: ' . print_r($dbError, true));

        if ($result) {
            echo json_encode(['success' => true, 'message' => 'Tipo de obra salvo com sucesso', 'id' => $result]);
        } else {
            $msg = 'Erro ao salvar tipo de obra';
            if ($dbError && !empty($dbError['message'])) {
                if (strpos($dbError['message'], 'Duplicate') !== false && strpos($dbError['message'], 'uk_nome') !== false) {
                    $msg = 'Já existe um tipo de obra com este nome';
                } else {
                    $msg = 'Erro ao salvar tipo de obra';
                }
            }
            echo json_encode(['success' => false, 'message' => $msg]);
        }
    }

    public function excluirTipoObra()
    {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'dObras')) {
            echo json_encode(['success' => false, 'message' => 'Sem permissão']);
            return;
        }

        $id = $this->input->post('id');
        if (!$id || !is_numeric($id)) {
            echo json_encode(['success' => false, 'message' => 'ID inválido']);
            return;
        }

        $result = $this->obras_model->excluirTipoObra($id);

        if ($result) {
            echo json_encode(['success' => true, 'message' => 'Tipo de obra excluído com sucesso']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao excluir tipo de obra']);
        }
    }

    // ============================================
    // CONFIGURACOES - STATUS DE OBRA
    // ============================================

    public function salvarStatusObra()
    {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'cObras')) {
            echo json_encode(['success' => false, 'message' => 'Sem permissão']);
            return;
        }

        $dados = [
            'id' => $this->input->post('id') ?: null,
            'nome' => $this->input->post('nome'),
            'descricao' => $this->input->post('descricao'),
            'cor' => $this->input->post('cor') ?: '#3498db',
            'icone' => $this->input->post('icone') ?: 'bx-flag',
            'ordem' => $this->input->post('ordem') ?: 1,
            'finalizado' => $this->input->post('finalizado') ? 1 : 0,
        ];

        if (empty($dados['nome'])) {
            echo json_encode(['success' => false, 'message' => 'Nome do status é obrigatório']);
            return;
        }

        // Verificar duplicata
        if (empty($dados['id'])) {
            $existe = $this->db->where('nome', $dados['nome'])->where('ativo', 1)->count_all_results('obra_status');
            if ($existe > 0) {
                echo json_encode(['success' => false, 'message' => 'Já existe um status de obra com o nome "' . $dados['nome'] . '"']);
                return;
            }
        } else {
            $this->db->where('nome', $dados['nome']);
            $this->db->where('id !=', $dados['id']);
            $this->db->where('ativo', 1);
            $existe = $this->db->count_all_results('obra_status');
            if ($existe > 0) {
                echo json_encode(['success' => false, 'message' => 'Já existe outro status de obra com o nome "' . $dados['nome'] . '"']);
                return;
            }
        }

        $result = $this->obras_model->salvarStatusObra($dados);
        $dbError = $this->db->error();

        if ($result) {
            echo json_encode(['success' => true, 'message' => 'Status de obra salvo com sucesso', 'id' => $result]);
        } else {
            $msg = 'Erro ao salvar status de obra';
            if ($dbError && !empty($dbError['message'])) {
                if (strpos($dbError['message'], 'Duplicate') !== false && strpos($dbError['message'], 'uk_nome') !== false) {
                    $msg = 'Já existe um status de obra com este nome';
                }
            }
            echo json_encode(['success' => false, 'message' => $msg]);
        }
    }

    public function excluirStatusObra()
    {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'dObras')) {
            echo json_encode(['success' => false, 'message' => 'Sem permissão']);
            return;
        }

        $id = $this->input->post('id');
        if (!$id || !is_numeric($id)) {
            echo json_encode(['success' => false, 'message' => 'ID inválido']);
            return;
        }

        $result = $this->obras_model->excluirStatusObra($id);

        if ($result) {
            echo json_encode(['success' => true, 'message' => 'Status de obra excluído com sucesso']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao excluir status de obra']);
        }
    }

    // ============================================
    // CONFIGURACOES - ESPECIALIDADES
    // ============================================

    public function salvarEspecialidade()
    {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'cObras')) {
            echo json_encode(['success' => false, 'message' => 'Sem permissão']);
            return;
        }

        $dados = [
            'id' => $this->input->post('id') ?: null,
            'nome' => $this->input->post('nome'),
            'descricao' => $this->input->post('descricao'),
            'cor' => $this->input->post('cor') ?: '#3498db',
            'icone' => $this->input->post('icone') ?: 'bx-hard-hat',
        ];

        if (empty($dados['nome'])) {
            echo json_encode(['success' => false, 'message' => 'Nome da especialidade é obrigatório']);
            return;
        }

        // Verificar duplicata
        if (empty($dados['id'])) {
            $existe = $this->db->where('nome', $dados['nome'])->where('ativo', 1)->count_all_results('obra_especialidades');
            if ($existe > 0) {
                echo json_encode(['success' => false, 'message' => 'Já existe uma especialidade com o nome "' . $dados['nome'] . '"']);
                return;
            }
        } else {
            $this->db->where('nome', $dados['nome']);
            $this->db->where('id !=', $dados['id']);
            $this->db->where('ativo', 1);
            $existe = $this->db->count_all_results('obra_especialidades');
            if ($existe > 0) {
                echo json_encode(['success' => false, 'message' => 'Já existe outra especialidade com o nome "' . $dados['nome'] . '"']);
                return;
            }
        }

        $result = $this->obras_model->salvarEspecialidade($dados);
        $dbError = $this->db->error();

        if ($result) {
            echo json_encode(['success' => true, 'message' => 'Especialidade salva com sucesso', 'id' => $result]);
        } else {
            $msg = 'Erro ao salvar especialidade';
            if ($dbError && !empty($dbError['message'])) {
                if (strpos($dbError['message'], 'Duplicate') !== false && strpos($dbError['message'], 'uk_nome') !== false) {
                    $msg = 'Já existe uma especialidade com este nome';
                }
            }
            echo json_encode(['success' => false, 'message' => $msg]);
        }
    }

    public function excluirEspecialidade()
    {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'dObras')) {
            echo json_encode(['success' => false, 'message' => 'Sem permissão']);
            return;
        }

        $id = $this->input->post('id');
        if (!$id || !is_numeric($id)) {
            echo json_encode(['success' => false, 'message' => 'ID inválido']);
            return;
        }

        $result = $this->obras_model->excluirEspecialidade($id);

        if ($result) {
            echo json_encode(['success' => true, 'message' => 'Especialidade excluída com sucesso']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao excluir especialidade']);
        }
    }

    // ============================================
    // CONFIGURACOES - TIPOS DE ATIVIDADE
    // ============================================

    public function salvarTipoAtividade()
    {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'cObras')) {
            echo json_encode(['success' => false, 'message' => 'Sem permissão']);
            return;
        }

        $this->load->model('atividades_tipos_model');

        $dados = [
            'idTipo' => $this->input->post('id') ?: null,
            'nome' => $this->input->post('nome'),
            'descricao' => $this->input->post('descricao'),
            'categoria' => $this->input->post('categoria') ?: 'outro',
            'duracao_estimada' => $this->input->post('duracao') ?: 30,
            'cor' => $this->input->post('cor') ?: '#3498db',
            'icone' => $this->input->post('icone') ?: 'bx-wrench',
        ];

        if (empty($dados['nome'])) {
            echo json_encode(['success' => false, 'message' => 'Nome do tipo é obrigatório']);
            return;
        }

        // Verificar duplicata
        if (empty($dados['idTipo'])) {
            $existe = $this->db->where('nome', $dados['nome'])->where('ativo', 1)->count_all_results('atividades_tipos');
            if ($existe > 0) {
                echo json_encode(['success' => false, 'message' => 'Já existe um tipo de atividade com o nome "' . $dados['nome'] . '"']);
                return;
            }
        } else {
            $this->db->where('nome', $dados['nome']);
            $this->db->where('idTipo !=', $dados['idTipo']);
            $this->db->where('ativo', 1);
            $existe = $this->db->count_all_results('atividades_tipos');
            if ($existe > 0) {
                echo json_encode(['success' => false, 'message' => 'Já existe outro tipo de atividade com o nome "' . $dados['nome'] . '"']);
                return;
            }
        }

        if (!empty($dados['idTipo'])) {
            $this->db->where('idTipo', $dados['idTipo']);
            $this->db->update('atividades_tipos', $dados);
            $result = $dados['idTipo'];
        } else {
            unset($dados['idTipo']);
            $this->db->insert('atividades_tipos', $dados);
            $result = $this->db->insert_id();
        }

        if ($result) {
            echo json_encode(['success' => true, 'message' => 'Tipo de atividade salvo com sucesso', 'id' => $result]);
        } else {
            $dbError = $this->db->error();
            $msg = 'Erro ao salvar tipo de atividade';
            if ($dbError && !empty($dbError['message'])) {
                if (strpos($dbError['message'], 'Duplicate') !== false) {
                    $msg = 'Já existe um tipo de atividade com este nome';
                }
            }
            echo json_encode(['success' => false, 'message' => $msg]);
        }
    }

    public function excluirTipoAtividade()
    {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'dObras')) {
            echo json_encode(['success' => false, 'message' => 'Sem permissão']);
            return;
        }

        $id = $this->input->post('id');
        if (!$id || !is_numeric($id)) {
            echo json_encode(['success' => false, 'message' => 'ID inválido']);
            return;
        }

        $this->db->where('idTipo', $id);
        $this->db->delete('atividades_tipos');

        if ($this->db->affected_rows() >= 0) {
            echo json_encode(['success' => true, 'message' => 'Tipo de atividade excluído com sucesso']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao excluir tipo de atividade']);
        }
    }

    // ============================================
    // CONFIGURACOES - STATUS DE ATIVIDADE
    // ============================================

    public function salvarStatusAtividade()
    {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'cObras')) {
            echo json_encode(['success' => false, 'message' => 'Sem permissão']);
            return;
        }

        $this->load->model('atividades_model');

        $dados = [
            'id' => $this->input->post('id') ?: null,
            'nome' => $this->input->post('nome'),
            'descricao' => $this->input->post('descricao'),
            'cor' => $this->input->post('cor') ?: '#3498db',
            'icone' => $this->input->post('icone') ?: 'bx-calendar',
            'fluxo' => $this->input->post('fluxo') ?: 'normal',
        ];

        if (empty($dados['nome'])) {
            echo json_encode(['success' => false, 'message' => 'Nome do status é obrigatório']);
            return;
        }

        if (!empty($dados['id'])) {
            $this->db->where('id', $dados['id']);
            $this->db->update('atividade_status', $dados);
            $result = $dados['id'];
        } else {
            // Verificar duplicata
            $existe = $this->db->where('nome', $dados['nome'])->where('ativo', 1)->count_all_results('atividade_status');
            if ($existe > 0) {
                echo json_encode(['success' => false, 'message' => 'Já existe um status de atividade com o nome "' . $dados['nome'] . '"']);
                return;
            }
            unset($dados['id']);
            $this->db->insert('atividade_status', $dados);
            $result = $this->db->insert_id();
        }

        if ($result) {
            echo json_encode(['success' => true, 'message' => 'Status de atividade salvo com sucesso', 'id' => $result]);
        } else {
            $dbError = $this->db->error();
            $msg = 'Erro ao salvar status de atividade';
            if ($dbError && !empty($dbError['message'])) {
                if (strpos($dbError['message'], 'Duplicate') !== false) {
                    $msg = 'Já existe um status de atividade com este nome';
                }
            }
            echo json_encode(['success' => false, 'message' => $msg]);
        }
    }

    public function excluirStatusAtividade()
    {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        if (!$this->permission->checkPermission($this->session->userdata('permissao'), 'dObras')) {
            echo json_encode(['success' => false, 'message' => 'Sem permissão']);
            return;
        }

        $id = $this->input->post('id');
        if (!$id || !is_numeric($id)) {
            echo json_encode(['success' => false, 'message' => 'ID inválido']);
            return;
        }

        $this->db->where('id', $id);
        $this->db->delete('atividade_status');

        if ($this->db->affected_rows() >= 0) {
            echo json_encode(['success' => true, 'message' => 'Status de atividade excluído com sucesso']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao excluir status de atividade']);
        }
    }
}
