<?php

if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Permissoes extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();

        if (! $this->permission->checkPermission($this->session->userdata('permissao'), 'cPermissao')) {
            $this->session->set_flashdata('error', 'Você não tem permissão para configurar as permissões no sistema.');
            redirect(base_url());
        }

        $this->load->helper(['form', 'codegen_helper']);
        $this->load->model('permissoes_model');
        $this->data['menuConfiguracoes'] = 'Permissões';
    }

    public function index()
    {
        $this->gerenciar();
    }

    public function gerenciar()
    {
        $this->load->library('pagination');

        $this->data['configuration']['base_url'] = site_url('permissoes/gerenciar/');
        $this->data['configuration']['total_rows'] = $this->permissoes_model->count('permissoes');

        $this->pagination->initialize($this->data['configuration']);

        $this->data['results'] = $this->permissoes_model->get('permissoes', 'idPermissao,nome,data,situacao', '', $this->data['configuration']['per_page'], $this->uri->segment(3));

        $this->data['view'] = 'permissoes/permissoes';

        return $this->layout();
    }

    public function adicionar()
    {
        $this->load->library('form_validation');
        $this->data['custom_error'] = '';

        $this->form_validation->set_rules('nome', 'Nome', 'trim|required');
        if ($this->form_validation->run() == false) {
            $this->data['custom_error'] = (validation_errors() ? '<div class="form_error">' . validation_errors() . '</div>' : false);
        } else {
            $nomePermissao = $this->input->post('nome');
            $cadastro = date('Y-m-d');
            $situacao = 1;

            $permissoes = [

                'aCliente' => $this->input->post('aCliente'),
                'eCliente' => $this->input->post('eCliente'),
                'dCliente' => $this->input->post('dCliente'),
                'vCliente' => $this->input->post('vCliente'),

                'aProduto' => $this->input->post('aProduto'),
                'eProduto' => $this->input->post('eProduto'),
                'dProduto' => $this->input->post('dProduto'),
                'vProduto' => $this->input->post('vProduto'),

                'aServico' => $this->input->post('aServico'),
                'eServico' => $this->input->post('eServico'),
                'dServico' => $this->input->post('dServico'),
                'vServico' => $this->input->post('vServico'),

                'aOs' => $this->input->post('aOs'),
                'eOs' => $this->input->post('eOs'),
                'dOs' => $this->input->post('dOs'),
                'vOs' => $this->input->post('vOs'),
                'vBtnAtendimento' => $this->input->post('vBtnAtendimento'),
                'vTecnicoOS' => $this->input->post('vTecnicoOS'),
                'eTecnicoCheckin' => $this->input->post('eTecnicoCheckin'),
                'eTecnicoCheckout' => $this->input->post('eTecnicoCheckout'),
                'eTecnicoFotos' => $this->input->post('eTecnicoFotos'),
                'vTecnicoFotos' => $this->input->post('vTecnicoFotos'),
                'vTecnicoAssinaturas' => $this->input->post('vTecnicoAssinaturas'),

                'aVenda' => $this->input->post('aVenda'),
                'eVenda' => $this->input->post('eVenda'),
                'dVenda' => $this->input->post('dVenda'),
                'vVenda' => $this->input->post('vVenda'),

                'aGarantia' => $this->input->post('aGarantia'),
                'eGarantia' => $this->input->post('eGarantia'),
                'dGarantia' => $this->input->post('dGarantia'),
                'vGarantia' => $this->input->post('vGarantia'),

                'aArquivo' => $this->input->post('aArquivo'),
                'eArquivo' => $this->input->post('eArquivo'),
                'dArquivo' => $this->input->post('dArquivo'),
                'vArquivo' => $this->input->post('vArquivo'),

                'aPagamento' => $this->input->post('aPagamento'),
                'ePagamento' => $this->input->post('ePagamento'),
                'dPagamento' => $this->input->post('dPagamento'),
                'vPagamento' => $this->input->post('vPagamento'),

                'aLancamento' => $this->input->post('aLancamento'),
                'eLancamento' => $this->input->post('eLancamento'),
                'dLancamento' => $this->input->post('dLancamento'),
                'vLancamento' => $this->input->post('vLancamento'),

                'cUsuario' => $this->input->post('cUsuario'),
                'cEmitente' => $this->input->post('cEmitente'),
                'cPermissao' => $this->input->post('cPermissao'),
                'cBackup' => $this->input->post('cBackup'),
                'cAuditoria' => $this->input->post('cAuditoria'),
                'cEmail' => $this->input->post('cEmail'),
                'cSistema' => $this->input->post('cSistema'),

                'rCliente' => $this->input->post('rCliente'),
                'rProduto' => $this->input->post('rProduto'),
                'rServico' => $this->input->post('rServico'),
                'rOs' => $this->input->post('rOs'),
                'rVenda' => $this->input->post('rVenda'),
                'rFinanceiro' => $this->input->post('rFinanceiro'),

                'aCobranca' => $this->input->post('aCobranca'),
                'eCobranca' => $this->input->post('eCobranca'),
                'dCobranca' => $this->input->post('dCobranca'),
                'vCobranca' => $this->input->post('vCobranca'),

                // Permissões Dashboard
                'vDashboard' => $this->input->post('vDashboard'),
                'vRelatorioCompleto' => $this->input->post('vRelatorioCompleto'),
                'vExportarDados' => $this->input->post('vExportarDados'),

                // Permissões Novas Funcionalidades
                'vCertificado' => $this->input->post('vCertificado'),
                'cCertificado' => $this->input->post('cCertificado'),
                'eCertificado' => $this->input->post('eCertificado'),
                'dCertificado' => $this->input->post('dCertificado'),
                'vImpostos' => $this->input->post('vImpostos'),
                'cImpostos' => $this->input->post('cImpostos'),
                'eImpostos' => $this->input->post('eImpostos'),
                'dImpostos' => $this->input->post('dImpostos'),
                'cImpostosConfig' => $this->input->post('cImpostosConfig'),
                'vImpostosRelatorio' => $this->input->post('vImpostosRelatorio'),
                'vImpostosExportar' => $this->input->post('vImpostosExportar'),
                // Permissões DRE Contábil
                'vDRE' => $this->input->post('vDRE'),
                'vDREDemonstracao' => $this->input->post('vDREDemonstracao'),
                'vDREContas' => $this->input->post('vDREContas'),
                'vDRELancamentos' => $this->input->post('vDRELancamentos'),
                'cDRE' => $this->input->post('cDRE'),
                'eDRE' => $this->input->post('eDRE'),
                'dDRE' => $this->input->post('dDRE'),
                'vRelatorioAtendimentos' => $this->input->post('vRelatorioAtendimentos'),
                'vWebhooks' => $this->input->post('vWebhooks'),
                'cDocOs' => $this->input->post('cDocOs'),

                // Permissões Relatório de Técnicos
                'vRelatorioTecnicos' => $this->input->post('vRelatorioTecnicos'),
                'vTecnicoDashboard' => $this->input->post('vTecnicoDashboard'),
                'cTecnico' => $this->input->post('cTecnico'),
                'aTecnicoOS' => $this->input->post('aTecnicoOS'),

                // Permissões Portal do Cliente - Usuários
                'vUsuariosCliente' => $this->input->post('vUsuariosCliente'),
                'cUsuariosCliente' => $this->input->post('cUsuariosCliente'),
                'eUsuariosCliente' => $this->input->post('eUsuariosCliente'),
                'dUsuariosCliente' => $this->input->post('dUsuariosCliente'),
                'cPermUsuariosCliente' => $this->input->post('cPermUsuariosCliente'),

                // Permissões NFSe e Boletos
                'vNFSe' => $this->input->post('vNFSe'),
                'cNFSe' => $this->input->post('cNFSe'),
                'eNFSe' => $this->input->post('eNFSe'),
                'vBoletoOS' => $this->input->post('vBoletoOS'),
                'cBoletoOS' => $this->input->post('cBoletoOS'),
                'eBoletoOS' => $this->input->post('eBoletoOS'),
                'rNFSe' => $this->input->post('rNFSe'),

                // Permissões Sistema de Obras
                'vObras' => $this->input->post('vObras'),
                'cObras' => $this->input->post('cObras'),
                'eObras' => $this->input->post('eObras'),
                'dObras' => $this->input->post('dObras'),
                'vObrasTodas' => $this->input->post('vObrasTodas'),
                'vObrasRelatorios' => $this->input->post('vObrasRelatorios'),
                'vTecnicoObra' => $this->input->post('vTecnicoObra'),
                'eTecnicoExec' => $this->input->post('eTecnicoExec'),
                'eTecnicoFotos' => $this->input->post('eTecnicoFotos'),
                'eTecnicoImped' => $this->input->post('eTecnicoImped'),

                // Permissões Agente IA
                'vAgenteIA' => $this->input->post('vAgenteIA'),
                'cAgenteIA' => $this->input->post('cAgenteIA'),
            ];

            // Converter null para '0' (checkbox desmarcado)
            foreach ($permissoes as $key => $val) {
                if ($val === null || $val === false) {
                    $permissoes[$key] = '0';
                }
            }

            $permissoes = serialize($permissoes);

            $data = [
                'nome' => $nomePermissao,
                'data' => $cadastro,
                'permissoes' => $permissoes,
                'situacao' => $situacao,
            ];

            if ($this->permissoes_model->add('permissoes', $data) == true) {
                $this->session->set_flashdata('success', 'Permissão adicionada com sucesso!');
                log_info('Adicionou uma permissão');
                redirect(site_url('permissoes/adicionar/'));
            } else {
                $this->data['custom_error'] = '<div class="form_error"><p>Ocorreu um erro.</p></div>';
            }
        }

        $this->data['view'] = 'permissoes/adicionarPermissao';

        return $this->layout();
    }

    public function editar()
    {
        $this->load->library('form_validation');
        $this->data['custom_error'] = '';

        $this->form_validation->set_rules('nome', 'Nome', 'trim|required');
        if ($this->form_validation->run() == false) {
            $this->data['custom_error'] = (validation_errors() ? '<div class="form_error">' . validation_errors() . '</div>' : false);
        } else {
            $nomePermissao = $this->input->post('nome');
            $situacao = $this->input->post('situacao');
            $permissoes = [

                'aCliente' => $this->input->post('aCliente'),
                'eCliente' => $this->input->post('eCliente'),
                'dCliente' => $this->input->post('dCliente'),
                'vCliente' => $this->input->post('vCliente'),

                'aProduto' => $this->input->post('aProduto'),
                'eProduto' => $this->input->post('eProduto'),
                'dProduto' => $this->input->post('dProduto'),
                'vProduto' => $this->input->post('vProduto'),

                'aServico' => $this->input->post('aServico'),
                'eServico' => $this->input->post('eServico'),
                'dServico' => $this->input->post('dServico'),
                'vServico' => $this->input->post('vServico'),

                'aOs' => $this->input->post('aOs'),
                'eOs' => $this->input->post('eOs'),
                'dOs' => $this->input->post('dOs'),
                'vOs' => $this->input->post('vOs'),
                'vBtnAtendimento' => $this->input->post('vBtnAtendimento'),
                'vTecnicoOS' => $this->input->post('vTecnicoOS'),
                'eTecnicoCheckin' => $this->input->post('eTecnicoCheckin'),
                'eTecnicoCheckout' => $this->input->post('eTecnicoCheckout'),
                'eTecnicoFotos' => $this->input->post('eTecnicoFotos'),
                'vTecnicoDashboard' => $this->input->post('vTecnicoDashboard'),
                'vTecnicoFotos' => $this->input->post('vTecnicoFotos'),
                'vTecnicoAssinaturas' => $this->input->post('vTecnicoAssinaturas'),
                'cTecnico' => $this->input->post('cTecnico'),
                'aTecnicoOS' => $this->input->post('aTecnicoOS'),

                'aVenda' => $this->input->post('aVenda'),
                'eVenda' => $this->input->post('eVenda'),
                'dVenda' => $this->input->post('dVenda'),
                'vVenda' => $this->input->post('vVenda'),

                'aGarantia' => $this->input->post('aGarantia'),
                'eGarantia' => $this->input->post('eGarantia'),
                'dGarantia' => $this->input->post('dGarantia'),
                'vGarantia' => $this->input->post('vGarantia'),

                'aArquivo' => $this->input->post('aArquivo'),
                'eArquivo' => $this->input->post('eArquivo'),
                'dArquivo' => $this->input->post('dArquivo'),
                'vArquivo' => $this->input->post('vArquivo'),

                'aPagamento' => $this->input->post('aPagamento'),
                'ePagamento' => $this->input->post('ePagamento'),
                'dPagamento' => $this->input->post('dPagamento'),
                'vPagamento' => $this->input->post('vPagamento'),

                'aLancamento' => $this->input->post('aLancamento'),
                'eLancamento' => $this->input->post('eLancamento'),
                'dLancamento' => $this->input->post('dLancamento'),
                'vLancamento' => $this->input->post('vLancamento'),

                'cUsuario' => $this->input->post('cUsuario'),
                'cEmitente' => $this->input->post('cEmitente'),
                'cPermissao' => $this->input->post('cPermissao'),
                'cBackup' => $this->input->post('cBackup'),
                'cAuditoria' => $this->input->post('cAuditoria'),
                'cEmail' => $this->input->post('cEmail'),
                'cSistema' => $this->input->post('cSistema'),
                'cDocOs' => $this->input->post('cDocOs'),

                'rCliente' => $this->input->post('rCliente'),
                'rProduto' => $this->input->post('rProduto'),
                'rServico' => $this->input->post('rServico'),
                'rOs' => $this->input->post('rOs'),
                'rVenda' => $this->input->post('rVenda'),
                'rFinanceiro' => $this->input->post('rFinanceiro'),
                'rNFSe' => $this->input->post('rNFSe'),

                'aCobranca' => $this->input->post('aCobranca'),
                'eCobranca' => $this->input->post('eCobranca'),
                'dCobranca' => $this->input->post('dCobranca'),
                'vCobranca' => $this->input->post('vCobranca'),

                'vDashboard' => $this->input->post('vDashboard'),
                'vRelatorioCompleto' => $this->input->post('vRelatorioCompleto'),
                'vExportarDados' => $this->input->post('vExportarDados'),

                'vCertificado' => $this->input->post('vCertificado'),
                'cCertificado' => $this->input->post('cCertificado'),
                'eCertificado' => $this->input->post('eCertificado'),
                'dCertificado' => $this->input->post('dCertificado'),
                'vImpostos' => $this->input->post('vImpostos'),
                'cImpostos' => $this->input->post('cImpostos'),
                'eImpostos' => $this->input->post('eImpostos'),
                'dImpostos' => $this->input->post('dImpostos'),
                'cImpostosConfig' => $this->input->post('cImpostosConfig'),
                'vImpostosRelatorio' => $this->input->post('vImpostosRelatorio'),
                'vImpostosExportar' => $this->input->post('vImpostosExportar'),

                'vDRE' => $this->input->post('vDRE'),
                'vDREDemonstracao' => $this->input->post('vDREDemonstracao'),
                'vDREContas' => $this->input->post('vDREContas'),
                'vDRELancamentos' => $this->input->post('vDRELancamentos'),
                'cDRE' => $this->input->post('cDRE'),
                'eDRE' => $this->input->post('eDRE'),
                'dDRE' => $this->input->post('dDRE'),
                'vRelatorioAtendimentos' => $this->input->post('vRelatorioAtendimentos'),
                'vWebhooks' => $this->input->post('vWebhooks'),

                'vRelatorioTecnicos' => $this->input->post('vRelatorioTecnicos'),

                'vUsuariosCliente' => $this->input->post('vUsuariosCliente'),
                'cUsuariosCliente' => $this->input->post('cUsuariosCliente'),
                'eUsuariosCliente' => $this->input->post('eUsuariosCliente'),
                'dUsuariosCliente' => $this->input->post('dUsuariosCliente'),
                'cPermUsuariosCliente' => $this->input->post('cPermUsuariosCliente'),

                'vNFSe' => $this->input->post('vNFSe'),
                'cNFSe' => $this->input->post('cNFSe'),
                'eNFSe' => $this->input->post('eNFSe'),
                'vBoletoOS' => $this->input->post('vBoletoOS'),
                'cBoletoOS' => $this->input->post('cBoletoOS'),
                'eBoletoOS' => $this->input->post('eBoletoOS'),

                // Permissões Sistema de Obras
                'vObras' => $this->input->post('vObras'),
                'cObras' => $this->input->post('cObras'),
                'eObras' => $this->input->post('eObras'),
                'dObras' => $this->input->post('dObras'),
                'vObrasTodas' => $this->input->post('vObrasTodas'),
                'vObrasRelatorios' => $this->input->post('vObrasRelatorios'),
                'vTecnicoObra' => $this->input->post('vTecnicoObra'),
                'eTecnicoExec' => $this->input->post('eTecnicoExec'),
                'eTecnicoFotos' => $this->input->post('eTecnicoFotos'),
                'eTecnicoImped' => $this->input->post('eTecnicoImped'),

                // Permissões Agente IA
                'vAgenteIA' => $this->input->post('vAgenteIA'),
                'cAgenteIA' => $this->input->post('cAgenteIA'),
                'eAgenteIA' => $this->input->post('eAgenteIA'),

                'categoria_d' => $this->input->post('categoria_d'),
                'categoria_v' => $this->input->post('categoria_v'),
                'categoria_a' => $this->input->post('categoria_a'),
                'categoria_e' => $this->input->post('categoria_e'),
                'vCategoria' => $this->input->post('vCategoria'),

                'aConfiguracao' => $this->input->post('aConfiguracao'),
                'eConfiguracao' => $this->input->post('eConfiguracao'),
                'dConfiguracao' => $this->input->post('dConfiguracao'),
                'vConfiguracao' => $this->input->post('vConfiguracao'),

                'aEmitente' => $this->input->post('aEmitente'),
                'eEmitente' => $this->input->post('eEmitente'),
                'dEmitente' => $this->input->post('dEmitente'),
                'vEmitente' => $this->input->post('vEmitente'),

                'aPermissao' => $this->input->post('aPermissao'),
                'ePermissao' => $this->input->post('ePermissao'),
                'dPermissao' => $this->input->post('dPermissao'),
                'vPermissao' => $this->input->post('vPermissao'),

                'aAuditoria' => $this->input->post('aAuditoria'),
                'eAuditoria' => $this->input->post('eAuditoria'),
                'dAuditoria' => $this->input->post('dAuditoria'),
                'vAuditoria' => $this->input->post('vAuditoria'),

                'aEmail' => $this->input->post('aEmail'),
                'eEmail' => $this->input->post('eEmail'),
                'dEmail' => $this->input->post('dEmail'),
                'vEmail' => $this->input->post('vEmail'),

                'rContas' => $this->input->post('rContas'),
                'rProdutos' => $this->input->post('rProdutos'),
                'rServicos' => $this->input->post('rServicos'),
                'rVendas' => $this->input->post('rVendas'),
                'rClientes' => $this->input->post('rClientes'),

            ];

            // Converter null para '0' (checkbox desmarcado) e preservar permissoes extras
            $current = $this->permissoes_model->getById($this->input->post('idPermissao'));
            $currentPerms = [];
            if ($current && !empty($current->permissoes)) {
                $decoded = @unserialize($current->permissoes);
                if (is_array($decoded)) {
                    $currentPerms = $decoded;
                }
            }

            // Checkbox desmarcado = null, precisa virar '0'
            foreach ($permissoes as $key => $val) {
                if ($val === null || $val === false) {
                    $permissoes[$key] = '0';
                }
            }

            // Preservar permissoes que existiam antes mas nao estao no formulario
            foreach ($currentPerms as $key => $val) {
                if (!isset($permissoes[$key])) {
                    $permissoes[$key] = $val;
                }
            }

            $permissoes = serialize($permissoes);

            $data = [
                'nome' => $nomePermissao,
                'permissoes' => $permissoes,
                'situacao' => $situacao,
            ];

            if ($this->permissoes_model->edit('permissoes', $data, 'idPermissao', $this->input->post('idPermissao')) == true) {
                $this->session->set_flashdata('success', 'Permissão editada com sucesso!');
                log_info('Alterou uma permissão. ID: ' . $this->input->post('idPermissao'));
                redirect(site_url('permissoes/editar/') . $this->input->post('idPermissao'));
            } else {
                $this->data['custom_error'] = '<div class="form_error"><p>Ocorreu um errro.</p></div>';
            }
        }

        $this->data['result'] = $this->permissoes_model->getById($this->uri->segment(3));

        $this->data['view'] = 'permissoes/editarPermissao';

        return $this->layout();
    }

    public function desativar()
    {
        $id = $this->input->post('id');
        if (! $id) {
            $this->session->set_flashdata('error', 'Erro ao tentar desativar permissão.');
            redirect(site_url('permissoes/gerenciar/'));
        }
        $data = [
            'situacao' => false,
        ];
        if ($this->permissoes_model->edit('permissoes', $data, 'idPermissao', $id)) {
            log_info('Desativou uma permissão. ID: ' . $id);
            $this->session->set_flashdata('success', 'Permissão desativada com sucesso!');
        } else {
            $this->session->set_flashdata('error', 'Erro ao desativar permissão!');
        }

        redirect(site_url('permissoes/gerenciar/'));
    }

    public function excluir()
    {
        $id = $this->input->post('id');
        if (! $id) {
            $this->session->set_flashdata('error', 'Erro ao tentar excluir permissão.');
            redirect(site_url('permissoes/gerenciar/'));
        }

        if ($id == 1) {
            $this->session->set_flashdata('error', 'O grupo Administrador não pode ser excluído!');
            redirect(site_url('permissoes/gerenciar/'));
        }

        $this->db->where('permissoes_id', $id);
        $usuarios = $this->db->get('usuarios')->num_rows();
        if ($usuarios > 0) {
            $this->session->set_flashdata('error', 'Existem ' . $usuarios . ' usuário(s) vinculado(s) a este grupo. Remova ou altere o grupo desses usuários antes de excluir.');
            redirect(site_url('permissoes/gerenciar/'));
        }

        if ($this->permissoes_model->delete('permissoes', 'idPermissao', $id)) {
            log_info('Excluiu uma permissão. ID: ' . $id);
            $this->session->set_flashdata('success', 'Permissão excluída com sucesso!');
        } else {
            $this->session->set_flashdata('error', 'Erro ao excluir permissão!');
        }

        redirect(site_url('permissoes/gerenciar/'));
    }
}

/* End of file permissoes.php */
/* Location: ./application/controllers/permissoes.php */
