<div class="span12" style="margin-left: 0">
    <form action="<?php echo base_url(); ?>index.php/permissoes/adicionar" id="formPermissao" method="post">
        <div class="span12" style="margin-left: 0">
            <div class="widget-box">
                <div class="widget-title" style="margin: -20px 0 0">
               <span class="icon">
               <i class="fas fa-lock"></i>
               </span>
                    <h5>Cadastro de Permissão</h5>
                </div>
                <div class="widget-content">
                    <div class="span6">
                        <label>Nome da Permissão</label>
                        <input name="nome" type="text" id="nome" class="span12" />
                    </div>
                    <div class="span6">
                        <br />
                        <label>
                            <input name="marcarTodos" type="checkbox" value="1" id="marcarTodos" />
                            <span class="lbl"> Marcar Todos</span>
                        </label>
                        <br />
                    </div>
                    <div class="accordion" id="collapse-group">
                        <div class="accordion-group widget-box">
                            <div class="accordion-heading">
                                <div class="widget-title">
                                    <a data-parent="#collapse-group" href="#collapseGOne" data-toggle="collapse">
                                      <span><i class='bx bx-group icon-cli'></i></span>
                                      <h5 style="padding-left: 28px">Clientes</h5>
                                    </a>
                                </div>
                            </div>
                            <div class="collapse in accordion-body" id="collapseGOne">
                                <div class="widget-content">
                                    <table class="table table-bordered">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="vCliente" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Visualizar Cliente</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="aCliente" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Adicionar Cliente</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="eCliente" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Editar Cliente</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="dCliente" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Excluir Cliente</span>
                                                </label>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-group widget-box">
                            <div class="accordion-heading">
                                <div class="widget-title">
                                    <a data-parent="#collapse-group" href="#collapseGTwo" data-toggle="collapse">
                                      <span><i class='bx bx-package icon-cli'></i></span>
                                      <h5 style="padding-left: 28px">Produtos</h5>
                                    </a>
                                </div>
                            </div>
                            <div class="collapse accordion-body" id="collapseGTwo">
                                <div class="widget-content">
                                    <table class="table table-bordered">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="vProduto" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Visualizar Produto</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="aProduto" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Adicionar Produto</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="eProduto" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Editar Produto</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="dProduto" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Excluir Produto</span>
                                                </label>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-group widget-box">
                            <div class="accordion-heading">
                                <div class="widget-title">
                                    <a data-parent="#collapse-group" href="#collapseGThree" data-toggle="collapse">
                                      <span><i class='bx bx-stopwatch icon-cli'></i></span>
                                      <h5 style="padding-left: 28px">Serviços</h5>
                                    </a>
                                </div>
                            </div>
                            <div class="collapse accordion-body" id="collapseGThree">
                                <div class="widget-content">
                                    <table class="table table-bordered">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="vServico" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Visualizar Serviço</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="aServico" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Adicionar Serviço</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="eServico" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Editar Serviço</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="dServico" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Excluir Serviço</span>
                                                </label>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-group widget-box">
                            <div class="accordion-heading">
                                <div class="widget-title">
                                    <a data-parent="#collapse-group" href="#collapseGThree3" data-toggle="collapse">
                                      <span><i class='bx bx-spreadsheet icon-cli'></i></span>
                                      <h5 style="padding-left: 28px">Ordem de Serviços - OS</h5>
                                    </a>
                                </div>
                            </div>
                            <div class="collapse accordion-body" id="collapseGThree3">
                                <div class="widget-content">
                                    <table class="table table-bordered">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="vOs" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Visualizar OS</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="aOs" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Adicionar OS</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="eOs" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Editar OS</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="dOs" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Excluir OS</span>
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="4">
                                                <label>
                                                    <input name="vBtnAtendimento" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Visualizar Botões Iniciar/Finalizar Atendimento</span>
                                                </label>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- SISTEMA DE OBRAS -->
                        <div class="accordion-group widget-box">
                            <div class="accordion-heading">
                                <div class="widget-title">
                                    <a data-parent="#collapse-group" href="#collapseGObras" data-toggle="collapse">
                                      <span><i class='bx bx-building-house icon-cli'></i></span>
                                      <h5 style="padding-left: 28px">Obras e Projetos</h5>
                                    </a>
                                </div>
                            </div>
                            <div class="collapse accordion-body" id="collapseGObras">
                                <div class="widget-content">
                                    <table class="table table-bordered">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="vObras" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Visualizar Obras</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="cObras" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Cadastrar Obras</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="eObras" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Editar Obras</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="dObras" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Excluir Obras</span>
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="vObrasTodas" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Visualizar Todas as Obras</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="vObrasRelatorios" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Relatórios de Obras</span>
                                                </label>
                                            </td>
                                            <td colspan="2"></td>
                                        </tr>
                                        </tbody>
                                    </table>

                                    <!-- Permissões de Técnico para Obras -->
                                    <div class="widget-title" style="background: #f5f5f5; padding: 5px; margin: 10px 0;">
                                        <h6 style="margin: 0;"><i class='bx bx-hard-hat'></i> Permissões do Técnico em Obras</h6>
                                    </div>
                                    <table class="table table-bordered">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="vTecnicoObra" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Ver Obras Atribuídas</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="eTecnicoExec" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Executar Atividades</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="eTecnicoFotos" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Adicionar Fotos</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="eTecnicoImped" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Registrar Impedimentos</span>
                                                </label>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="accordion-group widget-box">
                            <div class="accordion-heading">
                                <div class="widget-title">
                                    <a data-parent="#collapse-group" href="#collapseGTecnico" data-toggle="collapse">
                                      <span><i class='bx bx-user-check icon-cli'></i></span>
                                      <h5 style="padding-left: 28px">Permissões de Técnico (OS)</h5>
                                    </a>
                                </div>
                            </div>
                            <div class="collapse accordion-body" id="collapseGTecnico">
                                <div class="widget-content">
                                    <table class="table table-bordered">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="vTecnicoDashboard" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Dashboard Técnico</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="vTecnicoOS" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Visualizar apenas OS atribuídas</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="eTecnico" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Editar como Técnico</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="eTecnicoCheckin" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Iniciar Atendimento (Check-in)</span>
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="eTecnicoCheckout" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Finalizar Atendimento (Check-out)</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="eTecnicoFotos" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Adicionar Fotos ao Atendimento</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="vTecnicoFotos" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Visualizar Fotos do Atendimento</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="vTecnicoAssinaturas" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Visualizar Assinaturas</span>
                                                </label>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-group widget-box">
                            <div class="accordion-heading">
                                <div class="widget-title">
                                    <a data-parent="#collapse-group" href="#collapseGThree33" data-toggle="collapse">
                                      <span><i class='bx bx-cart-alt icon-cli'></i></span>
                                      <h5 style="padding-left: 28px">Vendas</h5>
                                    </a>
                                </div>
                            </div>
                            <div class="collapse accordion-body" id="collapseGThree33">
                                <div class="widget-content">
                                    <table class="table table-bordered">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="vVenda" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Visualizar Venda</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="aVenda" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Adicionar Venda</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="eVenda" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Editar Venda</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="dVenda" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Excluir Venda</span>
                                                </label>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-group widget-box">
                            <div class="accordion-heading">
                                <div class="widget-title">
                                    <a data-parent="#collapse-group" href="#collapseGThree333" data-toggle="collapse">
                                      <span><i class='bx bx-credit-card-front icon-cli'></i></span>
                                      <h5 style="padding-left: 28px">Cobranças</h5>
                                    </a>
                                </div>
                            </div>
                            <div class="collapse accordion-body" id="collapseGThree333">
                                <div class="widget-content">
                                    <table class="table table-bordered">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="vCobranca" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Visualizar Cobranças</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="aCobranca" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Adicionar Cobranças</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="eCobranca" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Editar Cobranças</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="dCobranca" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Excluir Cobranças</span>
                                                </label>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-group widget-box">
                            <div class="accordion-heading">
                                <div class="widget-title">
                                    <a data-parent="#collapse-group" href="#collapseGThree3333" data-toggle="collapse">
                                      <span><i class='bx bx-receipt icon-cli'></i></span>
                                      <h5 style="padding-left: 28px">Garantias</h5>
                                    </a>
                                </div>
                            </div>
                            <div class="collapse accordion-body" id="collapseGThree3333">
                                <div class="widget-content">
                                    <table class="table table-bordered">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="vGarantia" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Visualizar Garantia</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="aGarantia" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Adicionar Garantia</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="eGarantia" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Editar Garantia</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="dGarantia" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Excluir Garantia</span>
                                                </label>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-group widget-box">
                            <div class="accordion-heading">
                                <div class="widget-title">
                                    <a data-parent="#collapse-group" href="#collapseGThree33333" data-toggle="collapse">
                                      <span><i class='bx bx-box icon-cli'></i></span>
                                      <h5 style="padding-left: 28px">Arquivos</h5>
                                    </a>
                                </div>
                            </div>
                            <div class="collapse accordion-body" id="collapseGThree33333">
                                <div class="widget-content">
                                    <table class="table table-bordered">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="vArquivo" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Visualizar Arquivo</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="aArquivo" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Adicionar Arquivo</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="eArquivo" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Editar Arquivo</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="dArquivo" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Excluir Arquivo</span>
                                                </label>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-group widget-box">
                            <div class="accordion-heading">
                                <div class="widget-title">
                                    <a data-parent="#collapse-group" href="#collapseGThree333343" data-toggle="collapse">
                                      <span><i class="bx bx-bar-chart-square icon-cli"></i></span>
                                      <h5 style="padding-left: 28px">Financeiro</h5>
                                    </a>
                                </div>
                            </div>
                            <div class="collapse accordion-body" id="collapseGThree333343">
                                <div class="widget-content">
                                    <table class="table table-bordered">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="vPagamento" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Visualizar Pagamento</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="aPagamento" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Adicionar Pagamento</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="ePagamento" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Editar Pagamento</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="dPagamento" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Excluir Pagamento</span>
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="vLancamento" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Visualizar Lançamento</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="aLancamento" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Adicionar Lançamento</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="eLancamento" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Editar Lançamento</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="dLancamento" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Excluir Lançamento</span>
                                                </label>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-group widget-box">
                            <div class="accordion-heading">
                                <div class="widget-title">
                                    <a data-parent="#collapse-group" href="#collapseGThree333335" data-toggle="collapse">
                                      <span><i class="bx bx-chart icon-cli"></i></span>
                                      <h5 style="padding-left: 28px">Relatórios</h5>
                                    </a>
                                </div>
                            </div>
                            <div class="collapse accordion-body" id="collapseGThree333335">
                                <div class="widget-content">
                                    <table class="table table-bordered">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="rCliente" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Relatório Cliente</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="rServico" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Relatório Serviço</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="rOs" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Relatório OS</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="rProduto" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Relatório Produto</span>
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="rVenda" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Relatório Venda</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="rFinanceiro" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Relatório Financeiro</span>
                                                </label>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-group widget-box">
                            <div class="accordion-heading">
                                <div class="widget-title">
                                    <a data-parent="#collapse-group" href="#collapseGThree333339" data-toggle="collapse">
                                      <span><i class="bx bx-line-chart icon-cli"></i></span>
                                      <h5 style="padding-left: 28px">Dashboard</h5>
                                    </a>
                                </div>
                            </div>
                            <div class="collapse accordion-body" id="collapseGThree333339">
                                <div class="widget-content">
                                    <table class="table table-bordered">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="vDashboard" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Visualizar Dashboard</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="vRelatorioCompleto" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Relatório Completo</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="vExportarDados" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Exportar Dados</span>
                                                </label>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-group widget-box">
                            <div class="accordion-heading">
                                <div class="widget-title">
                                    <a data-parent="#collapse-group" href="#collapseGThree333338" data-toggle="collapse">
                                      <span><i class="bx bx-cog icon-cli"></i></span>
                                      <h5 style="padding-left: 28px">Configurações e Sistema</h5>
                                    </a>
                                </div>
                            </div>
                            <div class="collapse accordion-body" id="collapseGThree333338">
                                <div class="widget-content">
                                    <table class="table table-bordered">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="cUsuario" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Configurar Usuário</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="cEmitente" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Configurar Emitente</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="cPermissao" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Configurar Permissão</span>
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="cAuditoria" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Auditoria</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="cEmail" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Emails</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="cSistema" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Sistema</span>
                                                </label>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Backup -->
                    <div class="accordion-group widget-box">
                        <div class="accordion-heading">
                            <div class="widget-title">
                                <a data-parent="#collapse-group" href="#collapseGBackup" data-toggle="collapse">
                                    <span><i class="bx bx-data icon-cli"></i></span>
                                    <h5 style="padding-left: 28px">Backup</h5>
                                    <span><i class='bx bx-chevron-right icon-clic'></i></span>
                                </a>
                            </div>
                        </div>
                        <div class="collapse accordion-body" id="collapseGBackup">
                            <div class="widget-content">
                                <table class="table table-bordered">
                                    <tbody>
                                    <tr>
                                        <td colspan="4"></td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label>
                                                <input name="cBackup" class="marcar" type="checkbox" value="1" />
                                                <span class="lbl"> Acessar Backup</span>
                                            </label>
                                        </td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Novas Funcionalidades V5 -->
                    <div class="accordion-group widget-box">
                        <div class="accordion-heading">
                            <div class="widget-title">
                                <a data-parent="#collapse-group" href="#collapseGV5" data-toggle="collapse">
                                  <span><i class="bx bx-rocket icon-cli"></i></span>
                                  <h5 style="padding-left: 28px">Novas Funcionalidades V5</h5>
                                </a>
                            </div>
                        </div>
                        <div class="collapse accordion-body" id="collapseGV5">
                            <div class="widget-content">
                                <table class="table table-bordered">
                                    <tbody>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="vCertificado" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Visualizar Certificado</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="cCertificado" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Adicionar Certificado</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="eCertificado" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Editar Certificado</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="dCertificado" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Excluir Certificado</span>
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="vImpostos" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Visualizar Impostos</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="cImpostos" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Adicionar Impostos</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="eImpostos" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Editar Impostos</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="dImpostos" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Excluir Impostos</span>
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="cImpostosConfig" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Configurar Impostos</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="vImpostosRelatorio" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Relatório de Impostos</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="vImpostosExportar" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Exportar Impostos</span>
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="4" style="background-color: #f5f5f5; font-weight: bold; text-align: center;">
                                                <i class='bx bx-bar-chart-alt-2'></i> DRE Contábil
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="vDRE" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Visualizar DRE</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="vDREDemonstracao" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Demonstração DRE</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="vDREContas" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Plano de Contas</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="vDRELancamentos" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Lançamentos DRE</span>
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="cDRE" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Adicionar DRE</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="eDRE" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Editar DRE</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="dDRE" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Excluir DRE</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="vRelatorioAtendimentos" class="marcar" type="checkbox" checked="checked" value="1" />
                                                    <span class="lbl"> Relatório de Atendimentos</span>
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input name="vWebhooks" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Webhooks</span>
                                                </label>
                                            </td>
                                            <td>
                                                <label>
                                                    <input name="cDocOs" class="marcar" type="checkbox" value="1" />
                                                    <span class="lbl"> Vincular Documentos à OS</span>
                                                </label>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                <!-- Agente IA -->
                <div class="accordion-group widget-box">
                    <div class="accordion-heading">
                        <div class="widget-title">
                            <a data-parent="#collapse-group" href="#collapseGAgenteIA" data-toggle="collapse">
                                <span><i class='bx bx-bot icon-cli'></i></span>
                                <h5 style="padding-left: 28px">Agente IA (WhatsApp/n8n/LLMs)</h5>
                            </a>
                        </div>
                    </div>
                    <div class="collapse accordion-body" id="collapseGAgenteIA">
                        <div class="widget-content">
                            <table class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td colspan="4"></td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label>
                                                <input name="vAgenteIA" class="marcar" type="checkbox" checked="checked" value="1" />
                                                <span class="lbl"> Visualizar Painel Agente IA</span>
                                            </label>
                                        </td>
                                        <td>
                                            <label>
                                                <input name="cAgenteIA" class="marcar" type="checkbox" value="1" />
                                                <span class="lbl"> Configurar Agente IA</span>
                                            </label>
                                        </td>
                                        <td>
                                            <label>
                                                <input name="eAgenteIA" class="marcar" type="checkbox" value="1" />
                                                <span class="lbl"> Autorizar/Rejeitar Agente IA</span>
                                            </label>
                                        </td>
                                        <td colspan="2"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- NFSe e Boletos -->
                <div class="accordion-group widget-box">
                    <div class="accordion-heading">
                        <div class="widget-title">
                            <a data-parent="#collapse-group" href="#collapseGNFSe" data-toggle="collapse">
                                <span><i class='bx bx-receipt icon-cli'></i></span>
                                <h5 style="padding-left: 28px">NFSe e Boletos</h5>
                            </a>
                        </div>
                    </div>
                    <div class="collapse accordion-body" id="collapseGNFSe">
                        <div class="widget-content">
                            <table class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td colspan="4" style="background-color: #f5f5f5; font-weight: bold; text-align: center;">
                                            <i class='bx bx-file'></i> NFS-e (Nota Fiscal de Serviço)
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label>
                                                <input name="vNFSe" class="marcar" type="checkbox" checked="checked" value="1" />
                                                <span class="lbl"> Visualizar NFSe (OS)</span>
                                            </label>
                                        </td>
                                        <td>
                                            <label>
                                                <input name="cNFSe" class="marcar" type="checkbox" value="1" />
                                                <span class="lbl"> Cadastrar NFSe (OS)</span>
                                            </label>
                                        </td>
                                        <td>
                                            <label>
                                                <input name="eNFSe" class="marcar" type="checkbox" value="1" />
                                                <span class="lbl"> Editar/Cancelar NFSe (OS)</span>
                                            </label>
                                        </td>
                                        <td>
                                            <label>
                                                <input name="rNFSe" class="marcar" type="checkbox" value="1" />
                                                <span class="lbl"> Relatório NFSe</span>
                                            </label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="4" style="background-color: #f5f5f5; font-weight: bold; text-align: center;">
                                            <i class='bx bx-barcode'></i> Boletos de Cobrança
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label>
                                                <input name="vBoletoOS" class="marcar" type="checkbox" checked="checked" value="1" />
                                                <span class="lbl"> Visualizar Boleto OS</span>
                                            </label>
                                        </td>
                                        <td>
                                            <label>
                                                <input name="cBoletoOS" class="marcar" type="checkbox" value="1" />
                                                <span class="lbl"> Cadastrar Boleto OS</span>
                                            </label>
                                        </td>
                                        <td>
                                            <label>
                                                <input name="eBoletoOS" class="marcar" type="checkbox" value="1" />
                                                <span class="lbl"> Editar/Cancelar Boleto OS</span>
                                            </label>
                                        </td>
                                        <td>
                                            <label>
                                                <input name="pBoletoOS" class="marcar" type="checkbox" value="1" />
                                                <span class="lbl"> Registrar Pagamento Boleto</span>
                                            </label>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                    <div class="form-actions">
                        <div class="span12">
                            <div class="span6 offset3" style="display:flex;justify-content: center">
                                <button type="submit" class="button btn btn-success"><span class="button__icon"><i class='bx bx-plus-circle'></i></span><span class="button__text2">Confirmar</span></button>
                                <a title="Voltar" class="button btn btn-mini btn-warning" href="<?php echo site_url() ?>/permissoes">
                                  <span class="button__icon"><i class="bx bx-undo"></i></span> <span class="button__text2">Voltar</span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/validate.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#marcarTodos").change(function() {
            $("input:checkbox").prop('checked', $(this).prop("checked"));
        });
        $("#formPermissao").validate({
            rules: {
                nome: {
                    required: true
                }
            },
            messages: {
                nome: {
                    required: 'Campo obrigatório'
                }
            }
        });
    });
</script>
